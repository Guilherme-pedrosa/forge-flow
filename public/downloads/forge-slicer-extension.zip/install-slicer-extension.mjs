import { createRequire } from "node:module"; const require=createRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/.pnpm/xmlchars@2.2.0/node_modules/xmlchars/xml/1.0/ed5.js
var require_ed5 = __commonJS({
  "node_modules/.pnpm/xmlchars@2.2.0/node_modules/xmlchars/xml/1.0/ed5.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CHAR = "	\n\r -\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}";
    exports.S = " 	\r\n";
    exports.NAME_START_CHAR = ":A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}";
    exports.NAME_CHAR = "-" + exports.NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040";
    exports.CHAR_RE = new RegExp("^[" + exports.CHAR + "]$", "u");
    exports.S_RE = new RegExp("^[" + exports.S + "]+$", "u");
    exports.NAME_START_CHAR_RE = new RegExp("^[" + exports.NAME_START_CHAR + "]$", "u");
    exports.NAME_CHAR_RE = new RegExp("^[" + exports.NAME_CHAR + "]$", "u");
    exports.NAME_RE = new RegExp("^[" + exports.NAME_START_CHAR + "][" + exports.NAME_CHAR + "]*$", "u");
    exports.NMTOKEN_RE = new RegExp("^[" + exports.NAME_CHAR + "]+$", "u");
    var TAB = 9;
    var NL = 10;
    var CR = 13;
    var SPACE = 32;
    exports.S_LIST = [SPACE, NL, CR, TAB];
    function isChar(c) {
      return c >= SPACE && c <= 55295 || c === NL || c === CR || c === TAB || c >= 57344 && c <= 65533 || c >= 65536 && c <= 1114111;
    }
    exports.isChar = isChar;
    function isS(c) {
      return c === SPACE || c === NL || c === CR || c === TAB;
    }
    exports.isS = isS;
    function isNameStartChar(c) {
      return c >= 65 && c <= 90 || c >= 97 && c <= 122 || c === 58 || c === 95 || c === 8204 || c === 8205 || c >= 192 && c <= 214 || c >= 216 && c <= 246 || c >= 248 && c <= 767 || c >= 880 && c <= 893 || c >= 895 && c <= 8191 || c >= 8304 && c <= 8591 || c >= 11264 && c <= 12271 || c >= 12289 && c <= 55295 || c >= 63744 && c <= 64975 || c >= 65008 && c <= 65533 || c >= 65536 && c <= 983039;
    }
    exports.isNameStartChar = isNameStartChar;
    function isNameChar(c) {
      return isNameStartChar(c) || c >= 48 && c <= 57 || c === 45 || c === 46 || c === 183 || c >= 768 && c <= 879 || c >= 8255 && c <= 8256;
    }
    exports.isNameChar = isNameChar;
  }
});

// node_modules/.pnpm/xmlchars@2.2.0/node_modules/xmlchars/xml/1.1/ed2.js
var require_ed2 = __commonJS({
  "node_modules/.pnpm/xmlchars@2.2.0/node_modules/xmlchars/xml/1.1/ed2.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CHAR = "-\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}";
    exports.RESTRICTED_CHAR = "-\b\v\f-\x7F-\x84\x86-\x9F";
    exports.S = " 	\r\n";
    exports.NAME_START_CHAR = ":A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}";
    exports.NAME_CHAR = "-" + exports.NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040";
    exports.CHAR_RE = new RegExp("^[" + exports.CHAR + "]$", "u");
    exports.RESTRICTED_CHAR_RE = new RegExp("^[" + exports.RESTRICTED_CHAR + "]$", "u");
    exports.S_RE = new RegExp("^[" + exports.S + "]+$", "u");
    exports.NAME_START_CHAR_RE = new RegExp("^[" + exports.NAME_START_CHAR + "]$", "u");
    exports.NAME_CHAR_RE = new RegExp("^[" + exports.NAME_CHAR + "]$", "u");
    exports.NAME_RE = new RegExp("^[" + exports.NAME_START_CHAR + "][" + exports.NAME_CHAR + "]*$", "u");
    exports.NMTOKEN_RE = new RegExp("^[" + exports.NAME_CHAR + "]+$", "u");
    var TAB = 9;
    var NL = 10;
    var CR = 13;
    var SPACE = 32;
    exports.S_LIST = [SPACE, NL, CR, TAB];
    function isChar(c) {
      return c >= 1 && c <= 55295 || c >= 57344 && c <= 65533 || c >= 65536 && c <= 1114111;
    }
    exports.isChar = isChar;
    function isRestrictedChar(c) {
      return c >= 1 && c <= 8 || c === 11 || c === 12 || c >= 14 && c <= 31 || c >= 127 && c <= 132 || c >= 134 && c <= 159;
    }
    exports.isRestrictedChar = isRestrictedChar;
    function isCharAndNotRestricted(c) {
      return c === 9 || c === 10 || c === 13 || c > 31 && c < 127 || c === 133 || c > 159 && c <= 55295 || c >= 57344 && c <= 65533 || c >= 65536 && c <= 1114111;
    }
    exports.isCharAndNotRestricted = isCharAndNotRestricted;
    function isS(c) {
      return c === SPACE || c === NL || c === CR || c === TAB;
    }
    exports.isS = isS;
    function isNameStartChar(c) {
      return c >= 65 && c <= 90 || c >= 97 && c <= 122 || c === 58 || c === 95 || c === 8204 || c === 8205 || c >= 192 && c <= 214 || c >= 216 && c <= 246 || c >= 248 && c <= 767 || c >= 880 && c <= 893 || c >= 895 && c <= 8191 || c >= 8304 && c <= 8591 || c >= 11264 && c <= 12271 || c >= 12289 && c <= 55295 || c >= 63744 && c <= 64975 || c >= 65008 && c <= 65533 || c >= 65536 && c <= 983039;
    }
    exports.isNameStartChar = isNameStartChar;
    function isNameChar(c) {
      return isNameStartChar(c) || c >= 48 && c <= 57 || c === 45 || c === 46 || c === 183 || c >= 768 && c <= 879 || c >= 8255 && c <= 8256;
    }
    exports.isNameChar = isNameChar;
  }
});

// node_modules/.pnpm/xmlchars@2.2.0/node_modules/xmlchars/xmlns/1.0/ed3.js
var require_ed3 = __commonJS({
  "node_modules/.pnpm/xmlchars@2.2.0/node_modules/xmlchars/xmlns/1.0/ed3.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NC_NAME_START_CHAR = "A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}";
    exports.NC_NAME_CHAR = "-" + exports.NC_NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040";
    exports.NC_NAME_START_CHAR_RE = new RegExp("^[" + exports.NC_NAME_START_CHAR + "]$", "u");
    exports.NC_NAME_CHAR_RE = new RegExp("^[" + exports.NC_NAME_CHAR + "]$", "u");
    exports.NC_NAME_RE = new RegExp("^[" + exports.NC_NAME_START_CHAR + "][" + exports.NC_NAME_CHAR + "]*$", "u");
    function isNCNameStartChar(c) {
      return c >= 65 && c <= 90 || c === 95 || c >= 97 && c <= 122 || c >= 192 && c <= 214 || c >= 216 && c <= 246 || c >= 248 && c <= 767 || c >= 880 && c <= 893 || c >= 895 && c <= 8191 || c >= 8204 && c <= 8205 || c >= 8304 && c <= 8591 || c >= 11264 && c <= 12271 || c >= 12289 && c <= 55295 || c >= 63744 && c <= 64975 || c >= 65008 && c <= 65533 || c >= 65536 && c <= 983039;
    }
    exports.isNCNameStartChar = isNCNameStartChar;
    function isNCNameChar(c) {
      return isNCNameStartChar(c) || (c === 45 || c === 46 || c >= 48 && c <= 57 || c === 183 || c >= 768 && c <= 879 || c >= 8255 && c <= 8256);
    }
    exports.isNCNameChar = isNCNameChar;
  }
});

// node_modules/.pnpm/saxes@6.0.0/node_modules/saxes/saxes.js
var require_saxes = __commonJS({
  "node_modules/.pnpm/saxes@6.0.0/node_modules/saxes/saxes.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SaxesParser = exports.EVENTS = void 0;
    var ed5 = require_ed5();
    var ed2 = require_ed2();
    var NSed3 = require_ed3();
    var isS = ed5.isS;
    var isChar10 = ed5.isChar;
    var isNameStartChar = ed5.isNameStartChar;
    var isNameChar = ed5.isNameChar;
    var S_LIST = ed5.S_LIST;
    var NAME_RE = ed5.NAME_RE;
    var isChar11 = ed2.isChar;
    var isNCNameStartChar = NSed3.isNCNameStartChar;
    var isNCNameChar = NSed3.isNCNameChar;
    var NC_NAME_RE = NSed3.NC_NAME_RE;
    var XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";
    var XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/";
    var rootNS = {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment
      __proto__: null,
      xml: XML_NAMESPACE,
      xmlns: XMLNS_NAMESPACE
    };
    var XML_ENTITIES = {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment
      __proto__: null,
      amp: "&",
      gt: ">",
      lt: "<",
      quot: '"',
      apos: "'"
    };
    var EOC = -1;
    var NL_LIKE = -2;
    var S_BEGIN = 0;
    var S_BEGIN_WHITESPACE = 1;
    var S_DOCTYPE = 2;
    var S_DOCTYPE_QUOTE = 3;
    var S_DTD = 4;
    var S_DTD_QUOTED = 5;
    var S_DTD_OPEN_WAKA = 6;
    var S_DTD_OPEN_WAKA_BANG = 7;
    var S_DTD_COMMENT = 8;
    var S_DTD_COMMENT_ENDING = 9;
    var S_DTD_COMMENT_ENDED = 10;
    var S_DTD_PI = 11;
    var S_DTD_PI_ENDING = 12;
    var S_TEXT = 13;
    var S_ENTITY = 14;
    var S_OPEN_WAKA = 15;
    var S_OPEN_WAKA_BANG = 16;
    var S_COMMENT = 17;
    var S_COMMENT_ENDING = 18;
    var S_COMMENT_ENDED = 19;
    var S_CDATA = 20;
    var S_CDATA_ENDING = 21;
    var S_CDATA_ENDING_2 = 22;
    var S_PI_FIRST_CHAR = 23;
    var S_PI_REST = 24;
    var S_PI_BODY = 25;
    var S_PI_ENDING = 26;
    var S_XML_DECL_NAME_START = 27;
    var S_XML_DECL_NAME = 28;
    var S_XML_DECL_EQ = 29;
    var S_XML_DECL_VALUE_START = 30;
    var S_XML_DECL_VALUE = 31;
    var S_XML_DECL_SEPARATOR = 32;
    var S_XML_DECL_ENDING = 33;
    var S_OPEN_TAG = 34;
    var S_OPEN_TAG_SLASH = 35;
    var S_ATTRIB = 36;
    var S_ATTRIB_NAME = 37;
    var S_ATTRIB_NAME_SAW_WHITE = 38;
    var S_ATTRIB_VALUE = 39;
    var S_ATTRIB_VALUE_QUOTED = 40;
    var S_ATTRIB_VALUE_CLOSED = 41;
    var S_ATTRIB_VALUE_UNQUOTED = 42;
    var S_CLOSE_TAG = 43;
    var S_CLOSE_TAG_SAW_WHITE = 44;
    var TAB = 9;
    var NL = 10;
    var CR = 13;
    var SPACE = 32;
    var BANG = 33;
    var DQUOTE = 34;
    var AMP = 38;
    var SQUOTE = 39;
    var MINUS = 45;
    var FORWARD_SLASH = 47;
    var SEMICOLON = 59;
    var LESS = 60;
    var EQUAL = 61;
    var GREATER = 62;
    var QUESTION = 63;
    var OPEN_BRACKET = 91;
    var CLOSE_BRACKET = 93;
    var NEL = 133;
    var LS = 8232;
    var isQuote = (c) => c === DQUOTE || c === SQUOTE;
    var QUOTES = [DQUOTE, SQUOTE];
    var DOCTYPE_TERMINATOR = [...QUOTES, OPEN_BRACKET, GREATER];
    var DTD_TERMINATOR = [...QUOTES, LESS, CLOSE_BRACKET];
    var XML_DECL_NAME_TERMINATOR = [EQUAL, QUESTION, ...S_LIST];
    var ATTRIB_VALUE_UNQUOTED_TERMINATOR = [...S_LIST, GREATER, AMP, LESS];
    function nsPairCheck(parser, prefix, uri) {
      switch (prefix) {
        case "xml":
          if (uri !== XML_NAMESPACE) {
            parser.fail(`xml prefix must be bound to ${XML_NAMESPACE}.`);
          }
          break;
        case "xmlns":
          if (uri !== XMLNS_NAMESPACE) {
            parser.fail(`xmlns prefix must be bound to ${XMLNS_NAMESPACE}.`);
          }
          break;
        default:
      }
      switch (uri) {
        case XMLNS_NAMESPACE:
          parser.fail(prefix === "" ? `the default namespace may not be set to ${uri}.` : `may not assign a prefix (even "xmlns") to the URI ${XMLNS_NAMESPACE}.`);
          break;
        case XML_NAMESPACE:
          switch (prefix) {
            case "xml":
              break;
            case "":
              parser.fail(`the default namespace may not be set to ${uri}.`);
              break;
            default:
              parser.fail("may not assign the xml namespace to another prefix.");
          }
          break;
        default:
      }
    }
    function nsMappingCheck(parser, mapping) {
      for (const local of Object.keys(mapping)) {
        nsPairCheck(parser, local, mapping[local]);
      }
    }
    var isNCName = (name) => NC_NAME_RE.test(name);
    var isName = (name) => NAME_RE.test(name);
    var FORBIDDEN_START = 0;
    var FORBIDDEN_BRACKET = 1;
    var FORBIDDEN_BRACKET_BRACKET = 2;
    exports.EVENTS = [
      "xmldecl",
      "text",
      "processinginstruction",
      "doctype",
      "comment",
      "opentagstart",
      "attribute",
      "opentag",
      "closetag",
      "cdata",
      "error",
      "end",
      "ready"
    ];
    var EVENT_NAME_TO_HANDLER_NAME = {
      xmldecl: "xmldeclHandler",
      text: "textHandler",
      processinginstruction: "piHandler",
      doctype: "doctypeHandler",
      comment: "commentHandler",
      opentagstart: "openTagStartHandler",
      attribute: "attributeHandler",
      opentag: "openTagHandler",
      closetag: "closeTagHandler",
      cdata: "cdataHandler",
      error: "errorHandler",
      end: "endHandler",
      ready: "readyHandler"
    };
    var SaxesParser2 = class {
      /**
       * @param opt The parser options.
       */
      constructor(opt) {
        this.opt = opt !== null && opt !== void 0 ? opt : {};
        this.fragmentOpt = !!this.opt.fragment;
        const xmlnsOpt = this.xmlnsOpt = !!this.opt.xmlns;
        this.trackPosition = this.opt.position !== false;
        this.fileName = this.opt.fileName;
        if (xmlnsOpt) {
          this.nameStartCheck = isNCNameStartChar;
          this.nameCheck = isNCNameChar;
          this.isName = isNCName;
          this.processAttribs = this.processAttribsNS;
          this.pushAttrib = this.pushAttribNS;
          this.ns = Object.assign({ __proto__: null }, rootNS);
          const additional = this.opt.additionalNamespaces;
          if (additional != null) {
            nsMappingCheck(this, additional);
            Object.assign(this.ns, additional);
          }
        } else {
          this.nameStartCheck = isNameStartChar;
          this.nameCheck = isNameChar;
          this.isName = isName;
          this.processAttribs = this.processAttribsPlain;
          this.pushAttrib = this.pushAttribPlain;
        }
        this.stateTable = [
          /* eslint-disable @typescript-eslint/unbound-method */
          this.sBegin,
          this.sBeginWhitespace,
          this.sDoctype,
          this.sDoctypeQuote,
          this.sDTD,
          this.sDTDQuoted,
          this.sDTDOpenWaka,
          this.sDTDOpenWakaBang,
          this.sDTDComment,
          this.sDTDCommentEnding,
          this.sDTDCommentEnded,
          this.sDTDPI,
          this.sDTDPIEnding,
          this.sText,
          this.sEntity,
          this.sOpenWaka,
          this.sOpenWakaBang,
          this.sComment,
          this.sCommentEnding,
          this.sCommentEnded,
          this.sCData,
          this.sCDataEnding,
          this.sCDataEnding2,
          this.sPIFirstChar,
          this.sPIRest,
          this.sPIBody,
          this.sPIEnding,
          this.sXMLDeclNameStart,
          this.sXMLDeclName,
          this.sXMLDeclEq,
          this.sXMLDeclValueStart,
          this.sXMLDeclValue,
          this.sXMLDeclSeparator,
          this.sXMLDeclEnding,
          this.sOpenTag,
          this.sOpenTagSlash,
          this.sAttrib,
          this.sAttribName,
          this.sAttribNameSawWhite,
          this.sAttribValue,
          this.sAttribValueQuoted,
          this.sAttribValueClosed,
          this.sAttribValueUnquoted,
          this.sCloseTag,
          this.sCloseTagSawWhite
          /* eslint-enable @typescript-eslint/unbound-method */
        ];
        this._init();
      }
      /**
       * Indicates whether or not the parser is closed. If ``true``, wait for
       * the ``ready`` event to write again.
       */
      get closed() {
        return this._closed;
      }
      _init() {
        var _a;
        this.openWakaBang = "";
        this.text = "";
        this.name = "";
        this.piTarget = "";
        this.entity = "";
        this.q = null;
        this.tags = [];
        this.tag = null;
        this.topNS = null;
        this.chunk = "";
        this.chunkPosition = 0;
        this.i = 0;
        this.prevI = 0;
        this.carriedFromPrevious = void 0;
        this.forbiddenState = FORBIDDEN_START;
        this.attribList = [];
        const { fragmentOpt } = this;
        this.state = fragmentOpt ? S_TEXT : S_BEGIN;
        this.reportedTextBeforeRoot = this.reportedTextAfterRoot = this.closedRoot = this.sawRoot = fragmentOpt;
        this.xmlDeclPossible = !fragmentOpt;
        this.xmlDeclExpects = ["version"];
        this.entityReturnState = void 0;
        let { defaultXMLVersion } = this.opt;
        if (defaultXMLVersion === void 0) {
          if (this.opt.forceXMLVersion === true) {
            throw new Error("forceXMLVersion set but defaultXMLVersion is not set");
          }
          defaultXMLVersion = "1.0";
        }
        this.setXMLVersion(defaultXMLVersion);
        this.positionAtNewLine = 0;
        this.doctype = false;
        this._closed = false;
        this.xmlDecl = {
          version: void 0,
          encoding: void 0,
          standalone: void 0
        };
        this.line = 1;
        this.column = 0;
        this.ENTITIES = Object.create(XML_ENTITIES);
        (_a = this.readyHandler) === null || _a === void 0 ? void 0 : _a.call(this);
      }
      /**
       * The stream position the parser is currently looking at. This field is
       * zero-based.
       *
       * This field is not based on counting Unicode characters but is to be
       * interpreted as a plain index into a JavaScript string.
       */
      get position() {
        return this.chunkPosition + this.i;
      }
      /**
       * The column number of the next character to be read by the parser.  *
       * This field is zero-based. (The first column in a line is 0.)
       *
       * This field reports the index at which the next character would be in the
       * line if the line were represented as a JavaScript string.  Note that this
       * *can* be different to a count based on the number of *Unicode characters*
       * due to how JavaScript handles astral plane characters.
       *
       * See [[column]] for a number that corresponds to a count of Unicode
       * characters.
       */
      get columnIndex() {
        return this.position - this.positionAtNewLine;
      }
      /**
       * Set an event listener on an event. The parser supports one handler per
       * event type. If you try to set an event handler over an existing handler,
       * the old handler is silently overwritten.
       *
       * @param name The event to listen to.
       *
       * @param handler The handler to set.
       */
      on(name, handler) {
        this[EVENT_NAME_TO_HANDLER_NAME[name]] = handler;
      }
      /**
       * Unset an event handler.
       *
       * @parma name The event to stop listening to.
       */
      off(name) {
        this[EVENT_NAME_TO_HANDLER_NAME[name]] = void 0;
      }
      /**
       * Make an error object. The error object will have a message that contains
       * the ``fileName`` option passed at the creation of the parser. If position
       * tracking was turned on, it will also have line and column number
       * information.
       *
       * @param message The message describing the error to report.
       *
       * @returns An error object with a properly formatted message.
       */
      makeError(message) {
        var _a;
        let msg = (_a = this.fileName) !== null && _a !== void 0 ? _a : "";
        if (this.trackPosition) {
          if (msg.length > 0) {
            msg += ":";
          }
          msg += `${this.line}:${this.column}`;
        }
        if (msg.length > 0) {
          msg += ": ";
        }
        return new Error(msg + message);
      }
      /**
       * Report a parsing error. This method is made public so that client code may
       * check for issues that are outside the scope of this project and can report
       * errors.
       *
       * @param message The error to report.
       *
       * @returns this
       */
      fail(message) {
        const err = this.makeError(message);
        const handler = this.errorHandler;
        if (handler === void 0) {
          throw err;
        } else {
          handler(err);
        }
        return this;
      }
      /**
       * Write a XML data to the parser.
       *
       * @param chunk The XML data to write.
       *
       * @returns this
       */
      // We do need object for the type here. Yes, it often causes problems
      // but not in this case.
      write(chunk) {
        if (this.closed) {
          return this.fail("cannot write after close; assign an onready handler.");
        }
        let end = false;
        if (chunk === null) {
          end = true;
          chunk = "";
        } else if (typeof chunk === "object") {
          chunk = chunk.toString();
        }
        if (this.carriedFromPrevious !== void 0) {
          chunk = `${this.carriedFromPrevious}${chunk}`;
          this.carriedFromPrevious = void 0;
        }
        let limit = chunk.length;
        const lastCode = chunk.charCodeAt(limit - 1);
        if (!end && // A trailing CR or surrogate must be carried over to the next
        // chunk.
        (lastCode === CR || lastCode >= 55296 && lastCode <= 56319)) {
          this.carriedFromPrevious = chunk[limit - 1];
          limit--;
          chunk = chunk.slice(0, limit);
        }
        const { stateTable } = this;
        this.chunk = chunk;
        this.i = 0;
        while (this.i < limit) {
          stateTable[this.state].call(this);
        }
        this.chunkPosition += limit;
        return end ? this.end() : this;
      }
      /**
       * Close the current stream. Perform final well-formedness checks and reset
       * the parser tstate.
       *
       * @returns this
       */
      close() {
        return this.write(null);
      }
      /**
       * Get a single code point out of the current chunk. This updates the current
       * position if we do position tracking.
       *
       * This is the algorithm to use for XML 1.0.
       *
       * @returns The character read.
       */
      getCode10() {
        const { chunk, i } = this;
        this.prevI = i;
        this.i = i + 1;
        if (i >= chunk.length) {
          return EOC;
        }
        const code = chunk.charCodeAt(i);
        this.column++;
        if (code < 55296) {
          if (code >= SPACE || code === TAB) {
            return code;
          }
          switch (code) {
            case NL:
              this.line++;
              this.column = 0;
              this.positionAtNewLine = this.position;
              return NL;
            case CR:
              if (chunk.charCodeAt(i + 1) === NL) {
                this.i = i + 2;
              }
              this.line++;
              this.column = 0;
              this.positionAtNewLine = this.position;
              return NL_LIKE;
            default:
              this.fail("disallowed character.");
              return code;
          }
        }
        if (code > 56319) {
          if (!(code >= 57344 && code <= 65533)) {
            this.fail("disallowed character.");
          }
          return code;
        }
        const final = 65536 + (code - 55296) * 1024 + (chunk.charCodeAt(i + 1) - 56320);
        this.i = i + 2;
        if (final > 1114111) {
          this.fail("disallowed character.");
        }
        return final;
      }
      /**
       * Get a single code point out of the current chunk. This updates the current
       * position if we do position tracking.
       *
       * This is the algorithm to use for XML 1.1.
       *
       * @returns {number} The character read.
       */
      getCode11() {
        const { chunk, i } = this;
        this.prevI = i;
        this.i = i + 1;
        if (i >= chunk.length) {
          return EOC;
        }
        const code = chunk.charCodeAt(i);
        this.column++;
        if (code < 55296) {
          if (code > 31 && code < 127 || code > 159 && code !== LS || code === TAB) {
            return code;
          }
          switch (code) {
            case NL:
              this.line++;
              this.column = 0;
              this.positionAtNewLine = this.position;
              return NL;
            case CR: {
              const next = chunk.charCodeAt(i + 1);
              if (next === NL || next === NEL) {
                this.i = i + 2;
              }
            }
            case NEL:
            case LS:
              this.line++;
              this.column = 0;
              this.positionAtNewLine = this.position;
              return NL_LIKE;
            default:
              this.fail("disallowed character.");
              return code;
          }
        }
        if (code > 56319) {
          if (!(code >= 57344 && code <= 65533)) {
            this.fail("disallowed character.");
          }
          return code;
        }
        const final = 65536 + (code - 55296) * 1024 + (chunk.charCodeAt(i + 1) - 56320);
        this.i = i + 2;
        if (final > 1114111) {
          this.fail("disallowed character.");
        }
        return final;
      }
      /**
       * Like ``getCode`` but with the return value normalized so that ``NL`` is
       * returned for ``NL_LIKE``.
       */
      getCodeNorm() {
        const c = this.getCode();
        return c === NL_LIKE ? NL : c;
      }
      unget() {
        this.i = this.prevI;
        this.column--;
      }
      /**
       * Capture characters into a buffer until encountering one of a set of
       * characters.
       *
       * @param chars An array of codepoints. Encountering a character in the array
       * ends the capture. (``chars`` may safely contain ``NL``.)
       *
       * @return The character code that made the capture end, or ``EOC`` if we hit
       * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
       * instead.
       */
      captureTo(chars) {
        let { i: start } = this;
        const { chunk } = this;
        while (true) {
          const c = this.getCode();
          const isNLLike = c === NL_LIKE;
          const final = isNLLike ? NL : c;
          if (final === EOC || chars.includes(final)) {
            this.text += chunk.slice(start, this.prevI);
            return final;
          }
          if (isNLLike) {
            this.text += `${chunk.slice(start, this.prevI)}
`;
            start = this.i;
          }
        }
      }
      /**
       * Capture characters into a buffer until encountering a character.
       *
       * @param char The codepoint that ends the capture. **NOTE ``char`` MAY NOT
       * CONTAIN ``NL``.** Passing ``NL`` will result in buggy behavior.
       *
       * @return ``true`` if we ran into the character. Otherwise, we ran into the
       * end of the current chunk.
       */
      captureToChar(char) {
        let { i: start } = this;
        const { chunk } = this;
        while (true) {
          let c = this.getCode();
          switch (c) {
            case NL_LIKE:
              this.text += `${chunk.slice(start, this.prevI)}
`;
              start = this.i;
              c = NL;
              break;
            case EOC:
              this.text += chunk.slice(start);
              return false;
            default:
          }
          if (c === char) {
            this.text += chunk.slice(start, this.prevI);
            return true;
          }
        }
      }
      /**
       * Capture characters that satisfy ``isNameChar`` into the ``name`` field of
       * this parser.
       *
       * @return The character code that made the test fail, or ``EOC`` if we hit
       * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
       * instead.
       */
      captureNameChars() {
        const { chunk, i: start } = this;
        while (true) {
          const c = this.getCode();
          if (c === EOC) {
            this.name += chunk.slice(start);
            return EOC;
          }
          if (!isNameChar(c)) {
            this.name += chunk.slice(start, this.prevI);
            return c === NL_LIKE ? NL : c;
          }
        }
      }
      /**
       * Skip white spaces.
       *
       * @return The character that ended the skip, or ``EOC`` if we hit
       * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
       * instead.
       */
      skipSpaces() {
        while (true) {
          const c = this.getCodeNorm();
          if (c === EOC || !isS(c)) {
            return c;
          }
        }
      }
      setXMLVersion(version) {
        this.currentXMLVersion = version;
        if (version === "1.0") {
          this.isChar = isChar10;
          this.getCode = this.getCode10;
        } else {
          this.isChar = isChar11;
          this.getCode = this.getCode11;
        }
      }
      // STATE ENGINE METHODS
      // This needs to be a state separate from S_BEGIN_WHITESPACE because we want
      // to be sure never to come back to this state later.
      sBegin() {
        if (this.chunk.charCodeAt(0) === 65279) {
          this.i++;
          this.column++;
        }
        this.state = S_BEGIN_WHITESPACE;
      }
      sBeginWhitespace() {
        const iBefore = this.i;
        const c = this.skipSpaces();
        if (this.prevI !== iBefore) {
          this.xmlDeclPossible = false;
        }
        switch (c) {
          case LESS:
            this.state = S_OPEN_WAKA;
            if (this.text.length !== 0) {
              throw new Error("no-empty text at start");
            }
            break;
          case EOC:
            break;
          default:
            this.unget();
            this.state = S_TEXT;
            this.xmlDeclPossible = false;
        }
      }
      sDoctype() {
        var _a;
        const c = this.captureTo(DOCTYPE_TERMINATOR);
        switch (c) {
          case GREATER: {
            (_a = this.doctypeHandler) === null || _a === void 0 ? void 0 : _a.call(this, this.text);
            this.text = "";
            this.state = S_TEXT;
            this.doctype = true;
            break;
          }
          case EOC:
            break;
          default:
            this.text += String.fromCodePoint(c);
            if (c === OPEN_BRACKET) {
              this.state = S_DTD;
            } else if (isQuote(c)) {
              this.state = S_DOCTYPE_QUOTE;
              this.q = c;
            }
        }
      }
      sDoctypeQuote() {
        const q = this.q;
        if (this.captureToChar(q)) {
          this.text += String.fromCodePoint(q);
          this.q = null;
          this.state = S_DOCTYPE;
        }
      }
      sDTD() {
        const c = this.captureTo(DTD_TERMINATOR);
        if (c === EOC) {
          return;
        }
        this.text += String.fromCodePoint(c);
        if (c === CLOSE_BRACKET) {
          this.state = S_DOCTYPE;
        } else if (c === LESS) {
          this.state = S_DTD_OPEN_WAKA;
        } else if (isQuote(c)) {
          this.state = S_DTD_QUOTED;
          this.q = c;
        }
      }
      sDTDQuoted() {
        const q = this.q;
        if (this.captureToChar(q)) {
          this.text += String.fromCodePoint(q);
          this.state = S_DTD;
          this.q = null;
        }
      }
      sDTDOpenWaka() {
        const c = this.getCodeNorm();
        this.text += String.fromCodePoint(c);
        switch (c) {
          case BANG:
            this.state = S_DTD_OPEN_WAKA_BANG;
            this.openWakaBang = "";
            break;
          case QUESTION:
            this.state = S_DTD_PI;
            break;
          default:
            this.state = S_DTD;
        }
      }
      sDTDOpenWakaBang() {
        const char = String.fromCodePoint(this.getCodeNorm());
        const owb = this.openWakaBang += char;
        this.text += char;
        if (owb !== "-") {
          this.state = owb === "--" ? S_DTD_COMMENT : S_DTD;
          this.openWakaBang = "";
        }
      }
      sDTDComment() {
        if (this.captureToChar(MINUS)) {
          this.text += "-";
          this.state = S_DTD_COMMENT_ENDING;
        }
      }
      sDTDCommentEnding() {
        const c = this.getCodeNorm();
        this.text += String.fromCodePoint(c);
        this.state = c === MINUS ? S_DTD_COMMENT_ENDED : S_DTD_COMMENT;
      }
      sDTDCommentEnded() {
        const c = this.getCodeNorm();
        this.text += String.fromCodePoint(c);
        if (c === GREATER) {
          this.state = S_DTD;
        } else {
          this.fail("malformed comment.");
          this.state = S_DTD_COMMENT;
        }
      }
      sDTDPI() {
        if (this.captureToChar(QUESTION)) {
          this.text += "?";
          this.state = S_DTD_PI_ENDING;
        }
      }
      sDTDPIEnding() {
        const c = this.getCodeNorm();
        this.text += String.fromCodePoint(c);
        if (c === GREATER) {
          this.state = S_DTD;
        }
      }
      sText() {
        if (this.tags.length !== 0) {
          this.handleTextInRoot();
        } else {
          this.handleTextOutsideRoot();
        }
      }
      sEntity() {
        let { i: start } = this;
        const { chunk } = this;
        loop:
          while (true) {
            switch (this.getCode()) {
              case NL_LIKE:
                this.entity += `${chunk.slice(start, this.prevI)}
`;
                start = this.i;
                break;
              case SEMICOLON: {
                const { entityReturnState } = this;
                const entity = this.entity + chunk.slice(start, this.prevI);
                this.state = entityReturnState;
                let parsed;
                if (entity === "") {
                  this.fail("empty entity name.");
                  parsed = "&;";
                } else {
                  parsed = this.parseEntity(entity);
                  this.entity = "";
                }
                if (entityReturnState !== S_TEXT || this.textHandler !== void 0) {
                  this.text += parsed;
                }
                break loop;
              }
              case EOC:
                this.entity += chunk.slice(start);
                break loop;
              default:
            }
          }
      }
      sOpenWaka() {
        const c = this.getCode();
        if (isNameStartChar(c)) {
          this.state = S_OPEN_TAG;
          this.unget();
          this.xmlDeclPossible = false;
        } else {
          switch (c) {
            case FORWARD_SLASH:
              this.state = S_CLOSE_TAG;
              this.xmlDeclPossible = false;
              break;
            case BANG:
              this.state = S_OPEN_WAKA_BANG;
              this.openWakaBang = "";
              this.xmlDeclPossible = false;
              break;
            case QUESTION:
              this.state = S_PI_FIRST_CHAR;
              break;
            default:
              this.fail("disallowed character in tag name");
              this.state = S_TEXT;
              this.xmlDeclPossible = false;
          }
        }
      }
      sOpenWakaBang() {
        this.openWakaBang += String.fromCodePoint(this.getCodeNorm());
        switch (this.openWakaBang) {
          case "[CDATA[":
            if (!this.sawRoot && !this.reportedTextBeforeRoot) {
              this.fail("text data outside of root node.");
              this.reportedTextBeforeRoot = true;
            }
            if (this.closedRoot && !this.reportedTextAfterRoot) {
              this.fail("text data outside of root node.");
              this.reportedTextAfterRoot = true;
            }
            this.state = S_CDATA;
            this.openWakaBang = "";
            break;
          case "--":
            this.state = S_COMMENT;
            this.openWakaBang = "";
            break;
          case "DOCTYPE":
            this.state = S_DOCTYPE;
            if (this.doctype || this.sawRoot) {
              this.fail("inappropriately located doctype declaration.");
            }
            this.openWakaBang = "";
            break;
          default:
            if (this.openWakaBang.length >= 7) {
              this.fail("incorrect syntax.");
            }
        }
      }
      sComment() {
        if (this.captureToChar(MINUS)) {
          this.state = S_COMMENT_ENDING;
        }
      }
      sCommentEnding() {
        var _a;
        const c = this.getCodeNorm();
        if (c === MINUS) {
          this.state = S_COMMENT_ENDED;
          (_a = this.commentHandler) === null || _a === void 0 ? void 0 : _a.call(this, this.text);
          this.text = "";
        } else {
          this.text += `-${String.fromCodePoint(c)}`;
          this.state = S_COMMENT;
        }
      }
      sCommentEnded() {
        const c = this.getCodeNorm();
        if (c !== GREATER) {
          this.fail("malformed comment.");
          this.text += `--${String.fromCodePoint(c)}`;
          this.state = S_COMMENT;
        } else {
          this.state = S_TEXT;
        }
      }
      sCData() {
        if (this.captureToChar(CLOSE_BRACKET)) {
          this.state = S_CDATA_ENDING;
        }
      }
      sCDataEnding() {
        const c = this.getCodeNorm();
        if (c === CLOSE_BRACKET) {
          this.state = S_CDATA_ENDING_2;
        } else {
          this.text += `]${String.fromCodePoint(c)}`;
          this.state = S_CDATA;
        }
      }
      sCDataEnding2() {
        var _a;
        const c = this.getCodeNorm();
        switch (c) {
          case GREATER: {
            (_a = this.cdataHandler) === null || _a === void 0 ? void 0 : _a.call(this, this.text);
            this.text = "";
            this.state = S_TEXT;
            break;
          }
          case CLOSE_BRACKET:
            this.text += "]";
            break;
          default:
            this.text += `]]${String.fromCodePoint(c)}`;
            this.state = S_CDATA;
        }
      }
      // We need this separate state to check the first character fo the pi target
      // with this.nameStartCheck which allows less characters than this.nameCheck.
      sPIFirstChar() {
        const c = this.getCodeNorm();
        if (this.nameStartCheck(c)) {
          this.piTarget += String.fromCodePoint(c);
          this.state = S_PI_REST;
        } else if (c === QUESTION || isS(c)) {
          this.fail("processing instruction without a target.");
          this.state = c === QUESTION ? S_PI_ENDING : S_PI_BODY;
        } else {
          this.fail("disallowed character in processing instruction name.");
          this.piTarget += String.fromCodePoint(c);
          this.state = S_PI_REST;
        }
      }
      sPIRest() {
        const { chunk, i: start } = this;
        while (true) {
          const c = this.getCodeNorm();
          if (c === EOC) {
            this.piTarget += chunk.slice(start);
            return;
          }
          if (!this.nameCheck(c)) {
            this.piTarget += chunk.slice(start, this.prevI);
            const isQuestion = c === QUESTION;
            if (isQuestion || isS(c)) {
              if (this.piTarget === "xml") {
                if (!this.xmlDeclPossible) {
                  this.fail("an XML declaration must be at the start of the document.");
                }
                this.state = isQuestion ? S_XML_DECL_ENDING : S_XML_DECL_NAME_START;
              } else {
                this.state = isQuestion ? S_PI_ENDING : S_PI_BODY;
              }
            } else {
              this.fail("disallowed character in processing instruction name.");
              this.piTarget += String.fromCodePoint(c);
            }
            break;
          }
        }
      }
      sPIBody() {
        if (this.text.length === 0) {
          const c = this.getCodeNorm();
          if (c === QUESTION) {
            this.state = S_PI_ENDING;
          } else if (!isS(c)) {
            this.text = String.fromCodePoint(c);
          }
        } else if (this.captureToChar(QUESTION)) {
          this.state = S_PI_ENDING;
        }
      }
      sPIEnding() {
        var _a;
        const c = this.getCodeNorm();
        if (c === GREATER) {
          const { piTarget } = this;
          if (piTarget.toLowerCase() === "xml") {
            this.fail("the XML declaration must appear at the start of the document.");
          }
          (_a = this.piHandler) === null || _a === void 0 ? void 0 : _a.call(this, {
            target: piTarget,
            body: this.text
          });
          this.piTarget = this.text = "";
          this.state = S_TEXT;
        } else if (c === QUESTION) {
          this.text += "?";
        } else {
          this.text += `?${String.fromCodePoint(c)}`;
          this.state = S_PI_BODY;
        }
        this.xmlDeclPossible = false;
      }
      sXMLDeclNameStart() {
        const c = this.skipSpaces();
        if (c === QUESTION) {
          this.state = S_XML_DECL_ENDING;
          return;
        }
        if (c !== EOC) {
          this.state = S_XML_DECL_NAME;
          this.name = String.fromCodePoint(c);
        }
      }
      sXMLDeclName() {
        const c = this.captureTo(XML_DECL_NAME_TERMINATOR);
        if (c === QUESTION) {
          this.state = S_XML_DECL_ENDING;
          this.name += this.text;
          this.text = "";
          this.fail("XML declaration is incomplete.");
          return;
        }
        if (!(isS(c) || c === EQUAL)) {
          return;
        }
        this.name += this.text;
        this.text = "";
        if (!this.xmlDeclExpects.includes(this.name)) {
          switch (this.name.length) {
            case 0:
              this.fail("did not expect any more name/value pairs.");
              break;
            case 1:
              this.fail(`expected the name ${this.xmlDeclExpects[0]}.`);
              break;
            default:
              this.fail(`expected one of ${this.xmlDeclExpects.join(", ")}`);
          }
        }
        this.state = c === EQUAL ? S_XML_DECL_VALUE_START : S_XML_DECL_EQ;
      }
      sXMLDeclEq() {
        const c = this.getCodeNorm();
        if (c === QUESTION) {
          this.state = S_XML_DECL_ENDING;
          this.fail("XML declaration is incomplete.");
          return;
        }
        if (isS(c)) {
          return;
        }
        if (c !== EQUAL) {
          this.fail("value required.");
        }
        this.state = S_XML_DECL_VALUE_START;
      }
      sXMLDeclValueStart() {
        const c = this.getCodeNorm();
        if (c === QUESTION) {
          this.state = S_XML_DECL_ENDING;
          this.fail("XML declaration is incomplete.");
          return;
        }
        if (isS(c)) {
          return;
        }
        if (!isQuote(c)) {
          this.fail("value must be quoted.");
          this.q = SPACE;
        } else {
          this.q = c;
        }
        this.state = S_XML_DECL_VALUE;
      }
      sXMLDeclValue() {
        const c = this.captureTo([this.q, QUESTION]);
        if (c === QUESTION) {
          this.state = S_XML_DECL_ENDING;
          this.text = "";
          this.fail("XML declaration is incomplete.");
          return;
        }
        if (c === EOC) {
          return;
        }
        const value = this.text;
        this.text = "";
        switch (this.name) {
          case "version": {
            this.xmlDeclExpects = ["encoding", "standalone"];
            const version = value;
            this.xmlDecl.version = version;
            if (!/^1\.[0-9]+$/.test(version)) {
              this.fail("version number must match /^1\\.[0-9]+$/.");
            } else if (!this.opt.forceXMLVersion) {
              this.setXMLVersion(version);
            }
            break;
          }
          case "encoding":
            if (!/^[A-Za-z][A-Za-z0-9._-]*$/.test(value)) {
              this.fail("encoding value must match /^[A-Za-z0-9][A-Za-z0-9._-]*$/.");
            }
            this.xmlDeclExpects = ["standalone"];
            this.xmlDecl.encoding = value;
            break;
          case "standalone":
            if (value !== "yes" && value !== "no") {
              this.fail('standalone value must match "yes" or "no".');
            }
            this.xmlDeclExpects = [];
            this.xmlDecl.standalone = value;
            break;
          default:
        }
        this.name = "";
        this.state = S_XML_DECL_SEPARATOR;
      }
      sXMLDeclSeparator() {
        const c = this.getCodeNorm();
        if (c === QUESTION) {
          this.state = S_XML_DECL_ENDING;
          return;
        }
        if (!isS(c)) {
          this.fail("whitespace required.");
          this.unget();
        }
        this.state = S_XML_DECL_NAME_START;
      }
      sXMLDeclEnding() {
        var _a;
        const c = this.getCodeNorm();
        if (c === GREATER) {
          if (this.piTarget !== "xml") {
            this.fail("processing instructions are not allowed before root.");
          } else if (this.name !== "version" && this.xmlDeclExpects.includes("version")) {
            this.fail("XML declaration must contain a version.");
          }
          (_a = this.xmldeclHandler) === null || _a === void 0 ? void 0 : _a.call(this, this.xmlDecl);
          this.name = "";
          this.piTarget = this.text = "";
          this.state = S_TEXT;
        } else {
          this.fail("The character ? is disallowed anywhere in XML declarations.");
        }
        this.xmlDeclPossible = false;
      }
      sOpenTag() {
        var _a;
        const c = this.captureNameChars();
        if (c === EOC) {
          return;
        }
        const tag = this.tag = {
          name: this.name,
          attributes: /* @__PURE__ */ Object.create(null)
        };
        this.name = "";
        if (this.xmlnsOpt) {
          this.topNS = tag.ns = /* @__PURE__ */ Object.create(null);
        }
        (_a = this.openTagStartHandler) === null || _a === void 0 ? void 0 : _a.call(this, tag);
        this.sawRoot = true;
        if (!this.fragmentOpt && this.closedRoot) {
          this.fail("documents may contain only one root.");
        }
        switch (c) {
          case GREATER:
            this.openTag();
            break;
          case FORWARD_SLASH:
            this.state = S_OPEN_TAG_SLASH;
            break;
          default:
            if (!isS(c)) {
              this.fail("disallowed character in tag name.");
            }
            this.state = S_ATTRIB;
        }
      }
      sOpenTagSlash() {
        if (this.getCode() === GREATER) {
          this.openSelfClosingTag();
        } else {
          this.fail("forward-slash in opening tag not followed by >.");
          this.state = S_ATTRIB;
        }
      }
      sAttrib() {
        const c = this.skipSpaces();
        if (c === EOC) {
          return;
        }
        if (isNameStartChar(c)) {
          this.unget();
          this.state = S_ATTRIB_NAME;
        } else if (c === GREATER) {
          this.openTag();
        } else if (c === FORWARD_SLASH) {
          this.state = S_OPEN_TAG_SLASH;
        } else {
          this.fail("disallowed character in attribute name.");
        }
      }
      sAttribName() {
        const c = this.captureNameChars();
        if (c === EQUAL) {
          this.state = S_ATTRIB_VALUE;
        } else if (isS(c)) {
          this.state = S_ATTRIB_NAME_SAW_WHITE;
        } else if (c === GREATER) {
          this.fail("attribute without value.");
          this.pushAttrib(this.name, this.name);
          this.name = this.text = "";
          this.openTag();
        } else if (c !== EOC) {
          this.fail("disallowed character in attribute name.");
        }
      }
      sAttribNameSawWhite() {
        const c = this.skipSpaces();
        switch (c) {
          case EOC:
            return;
          case EQUAL:
            this.state = S_ATTRIB_VALUE;
            break;
          default:
            this.fail("attribute without value.");
            this.text = "";
            this.name = "";
            if (c === GREATER) {
              this.openTag();
            } else if (isNameStartChar(c)) {
              this.unget();
              this.state = S_ATTRIB_NAME;
            } else {
              this.fail("disallowed character in attribute name.");
              this.state = S_ATTRIB;
            }
        }
      }
      sAttribValue() {
        const c = this.getCodeNorm();
        if (isQuote(c)) {
          this.q = c;
          this.state = S_ATTRIB_VALUE_QUOTED;
        } else if (!isS(c)) {
          this.fail("unquoted attribute value.");
          this.state = S_ATTRIB_VALUE_UNQUOTED;
          this.unget();
        }
      }
      sAttribValueQuoted() {
        const { q, chunk } = this;
        let { i: start } = this;
        while (true) {
          switch (this.getCode()) {
            case q:
              this.pushAttrib(this.name, this.text + chunk.slice(start, this.prevI));
              this.name = this.text = "";
              this.q = null;
              this.state = S_ATTRIB_VALUE_CLOSED;
              return;
            case AMP:
              this.text += chunk.slice(start, this.prevI);
              this.state = S_ENTITY;
              this.entityReturnState = S_ATTRIB_VALUE_QUOTED;
              return;
            case NL:
            case NL_LIKE:
            case TAB:
              this.text += `${chunk.slice(start, this.prevI)} `;
              start = this.i;
              break;
            case LESS:
              this.text += chunk.slice(start, this.prevI);
              this.fail("disallowed character.");
              return;
            case EOC:
              this.text += chunk.slice(start);
              return;
            default:
          }
        }
      }
      sAttribValueClosed() {
        const c = this.getCodeNorm();
        if (isS(c)) {
          this.state = S_ATTRIB;
        } else if (c === GREATER) {
          this.openTag();
        } else if (c === FORWARD_SLASH) {
          this.state = S_OPEN_TAG_SLASH;
        } else if (isNameStartChar(c)) {
          this.fail("no whitespace between attributes.");
          this.unget();
          this.state = S_ATTRIB_NAME;
        } else {
          this.fail("disallowed character in attribute name.");
        }
      }
      sAttribValueUnquoted() {
        const c = this.captureTo(ATTRIB_VALUE_UNQUOTED_TERMINATOR);
        switch (c) {
          case AMP:
            this.state = S_ENTITY;
            this.entityReturnState = S_ATTRIB_VALUE_UNQUOTED;
            break;
          case LESS:
            this.fail("disallowed character.");
            break;
          case EOC:
            break;
          default:
            if (this.text.includes("]]>")) {
              this.fail('the string "]]>" is disallowed in char data.');
            }
            this.pushAttrib(this.name, this.text);
            this.name = this.text = "";
            if (c === GREATER) {
              this.openTag();
            } else {
              this.state = S_ATTRIB;
            }
        }
      }
      sCloseTag() {
        const c = this.captureNameChars();
        if (c === GREATER) {
          this.closeTag();
        } else if (isS(c)) {
          this.state = S_CLOSE_TAG_SAW_WHITE;
        } else if (c !== EOC) {
          this.fail("disallowed character in closing tag.");
        }
      }
      sCloseTagSawWhite() {
        switch (this.skipSpaces()) {
          case GREATER:
            this.closeTag();
            break;
          case EOC:
            break;
          default:
            this.fail("disallowed character in closing tag.");
        }
      }
      // END OF STATE ENGINE METHODS
      handleTextInRoot() {
        let { i: start, forbiddenState } = this;
        const { chunk, textHandler: handler } = this;
        scanLoop:
          while (true) {
            switch (this.getCode()) {
              case LESS: {
                this.state = S_OPEN_WAKA;
                if (handler !== void 0) {
                  const { text } = this;
                  const slice = chunk.slice(start, this.prevI);
                  if (text.length !== 0) {
                    handler(text + slice);
                    this.text = "";
                  } else if (slice.length !== 0) {
                    handler(slice);
                  }
                }
                forbiddenState = FORBIDDEN_START;
                break scanLoop;
              }
              case AMP:
                this.state = S_ENTITY;
                this.entityReturnState = S_TEXT;
                if (handler !== void 0) {
                  this.text += chunk.slice(start, this.prevI);
                }
                forbiddenState = FORBIDDEN_START;
                break scanLoop;
              case CLOSE_BRACKET:
                switch (forbiddenState) {
                  case FORBIDDEN_START:
                    forbiddenState = FORBIDDEN_BRACKET;
                    break;
                  case FORBIDDEN_BRACKET:
                    forbiddenState = FORBIDDEN_BRACKET_BRACKET;
                    break;
                  case FORBIDDEN_BRACKET_BRACKET:
                    break;
                  default:
                    throw new Error("impossible state");
                }
                break;
              case GREATER:
                if (forbiddenState === FORBIDDEN_BRACKET_BRACKET) {
                  this.fail('the string "]]>" is disallowed in char data.');
                }
                forbiddenState = FORBIDDEN_START;
                break;
              case NL_LIKE:
                if (handler !== void 0) {
                  this.text += `${chunk.slice(start, this.prevI)}
`;
                }
                start = this.i;
                forbiddenState = FORBIDDEN_START;
                break;
              case EOC:
                if (handler !== void 0) {
                  this.text += chunk.slice(start);
                }
                break scanLoop;
              default:
                forbiddenState = FORBIDDEN_START;
            }
          }
        this.forbiddenState = forbiddenState;
      }
      handleTextOutsideRoot() {
        let { i: start } = this;
        const { chunk, textHandler: handler } = this;
        let nonSpace = false;
        outRootLoop:
          while (true) {
            const code = this.getCode();
            switch (code) {
              case LESS: {
                this.state = S_OPEN_WAKA;
                if (handler !== void 0) {
                  const { text } = this;
                  const slice = chunk.slice(start, this.prevI);
                  if (text.length !== 0) {
                    handler(text + slice);
                    this.text = "";
                  } else if (slice.length !== 0) {
                    handler(slice);
                  }
                }
                break outRootLoop;
              }
              case AMP:
                this.state = S_ENTITY;
                this.entityReturnState = S_TEXT;
                if (handler !== void 0) {
                  this.text += chunk.slice(start, this.prevI);
                }
                nonSpace = true;
                break outRootLoop;
              case NL_LIKE:
                if (handler !== void 0) {
                  this.text += `${chunk.slice(start, this.prevI)}
`;
                }
                start = this.i;
                break;
              case EOC:
                if (handler !== void 0) {
                  this.text += chunk.slice(start);
                }
                break outRootLoop;
              default:
                if (!isS(code)) {
                  nonSpace = true;
                }
            }
          }
        if (!nonSpace) {
          return;
        }
        if (!this.sawRoot && !this.reportedTextBeforeRoot) {
          this.fail("text data outside of root node.");
          this.reportedTextBeforeRoot = true;
        }
        if (this.closedRoot && !this.reportedTextAfterRoot) {
          this.fail("text data outside of root node.");
          this.reportedTextAfterRoot = true;
        }
      }
      pushAttribNS(name, value) {
        var _a;
        const { prefix, local } = this.qname(name);
        const attr = { name, prefix, local, value };
        this.attribList.push(attr);
        (_a = this.attributeHandler) === null || _a === void 0 ? void 0 : _a.call(this, attr);
        if (prefix === "xmlns") {
          const trimmed = value.trim();
          if (this.currentXMLVersion === "1.0" && trimmed === "") {
            this.fail("invalid attempt to undefine prefix in XML 1.0");
          }
          this.topNS[local] = trimmed;
          nsPairCheck(this, local, trimmed);
        } else if (name === "xmlns") {
          const trimmed = value.trim();
          this.topNS[""] = trimmed;
          nsPairCheck(this, "", trimmed);
        }
      }
      pushAttribPlain(name, value) {
        var _a;
        const attr = { name, value };
        this.attribList.push(attr);
        (_a = this.attributeHandler) === null || _a === void 0 ? void 0 : _a.call(this, attr);
      }
      /**
       * End parsing. This performs final well-formedness checks and resets the
       * parser to a clean state.
       *
       * @returns this
       */
      end() {
        var _a, _b;
        if (!this.sawRoot) {
          this.fail("document must contain a root element.");
        }
        const { tags } = this;
        while (tags.length > 0) {
          const tag = tags.pop();
          this.fail(`unclosed tag: ${tag.name}`);
        }
        if (this.state !== S_BEGIN && this.state !== S_TEXT) {
          this.fail("unexpected end.");
        }
        const { text } = this;
        if (text.length !== 0) {
          (_a = this.textHandler) === null || _a === void 0 ? void 0 : _a.call(this, text);
          this.text = "";
        }
        this._closed = true;
        (_b = this.endHandler) === null || _b === void 0 ? void 0 : _b.call(this);
        this._init();
        return this;
      }
      /**
       * Resolve a namespace prefix.
       *
       * @param prefix The prefix to resolve.
       *
       * @returns The namespace URI or ``undefined`` if the prefix is not defined.
       */
      resolve(prefix) {
        var _a, _b;
        let uri = this.topNS[prefix];
        if (uri !== void 0) {
          return uri;
        }
        const { tags } = this;
        for (let index = tags.length - 1; index >= 0; index--) {
          uri = tags[index].ns[prefix];
          if (uri !== void 0) {
            return uri;
          }
        }
        uri = this.ns[prefix];
        if (uri !== void 0) {
          return uri;
        }
        return (_b = (_a = this.opt).resolvePrefix) === null || _b === void 0 ? void 0 : _b.call(_a, prefix);
      }
      /**
       * Parse a qname into its prefix and local name parts.
       *
       * @param name The name to parse
       *
       * @returns
       */
      qname(name) {
        const colon = name.indexOf(":");
        if (colon === -1) {
          return { prefix: "", local: name };
        }
        const local = name.slice(colon + 1);
        const prefix = name.slice(0, colon);
        if (prefix === "" || local === "" || local.includes(":")) {
          this.fail(`malformed name: ${name}.`);
        }
        return { prefix, local };
      }
      processAttribsNS() {
        var _a;
        const { attribList } = this;
        const tag = this.tag;
        {
          const { prefix, local } = this.qname(tag.name);
          tag.prefix = prefix;
          tag.local = local;
          const uri = tag.uri = (_a = this.resolve(prefix)) !== null && _a !== void 0 ? _a : "";
          if (prefix !== "") {
            if (prefix === "xmlns") {
              this.fail('tags may not have "xmlns" as prefix.');
            }
            if (uri === "") {
              this.fail(`unbound namespace prefix: ${JSON.stringify(prefix)}.`);
              tag.uri = prefix;
            }
          }
        }
        if (attribList.length === 0) {
          return;
        }
        const { attributes } = tag;
        const seen = /* @__PURE__ */ new Set();
        for (const attr of attribList) {
          const { name, prefix, local } = attr;
          let uri;
          let eqname;
          if (prefix === "") {
            uri = name === "xmlns" ? XMLNS_NAMESPACE : "";
            eqname = name;
          } else {
            uri = this.resolve(prefix);
            if (uri === void 0) {
              this.fail(`unbound namespace prefix: ${JSON.stringify(prefix)}.`);
              uri = prefix;
            }
            eqname = `{${uri}}${local}`;
          }
          if (seen.has(eqname)) {
            this.fail(`duplicate attribute: ${eqname}.`);
          }
          seen.add(eqname);
          attr.uri = uri;
          attributes[name] = attr;
        }
        this.attribList = [];
      }
      processAttribsPlain() {
        const { attribList } = this;
        const attributes = this.tag.attributes;
        for (const { name, value } of attribList) {
          if (attributes[name] !== void 0) {
            this.fail(`duplicate attribute: ${name}.`);
          }
          attributes[name] = value;
        }
        this.attribList = [];
      }
      /**
       * Handle a complete open tag. This parser code calls this once it has seen
       * the whole tag. This method checks for well-formeness and then emits
       * ``onopentag``.
       */
      openTag() {
        var _a;
        this.processAttribs();
        const { tags } = this;
        const tag = this.tag;
        tag.isSelfClosing = false;
        (_a = this.openTagHandler) === null || _a === void 0 ? void 0 : _a.call(this, tag);
        tags.push(tag);
        this.state = S_TEXT;
        this.name = "";
      }
      /**
       * Handle a complete self-closing tag. This parser code calls this once it has
       * seen the whole tag. This method checks for well-formeness and then emits
       * ``onopentag`` and ``onclosetag``.
       */
      openSelfClosingTag() {
        var _a, _b, _c;
        this.processAttribs();
        const { tags } = this;
        const tag = this.tag;
        tag.isSelfClosing = true;
        (_a = this.openTagHandler) === null || _a === void 0 ? void 0 : _a.call(this, tag);
        (_b = this.closeTagHandler) === null || _b === void 0 ? void 0 : _b.call(this, tag);
        const top = this.tag = (_c = tags[tags.length - 1]) !== null && _c !== void 0 ? _c : null;
        if (top === null) {
          this.closedRoot = true;
        }
        this.state = S_TEXT;
        this.name = "";
      }
      /**
       * Handle a complete close tag. This parser code calls this once it has seen
       * the whole tag. This method checks for well-formeness and then emits
       * ``onclosetag``.
       */
      closeTag() {
        const { tags, name } = this;
        this.state = S_TEXT;
        this.name = "";
        if (name === "") {
          this.fail("weird empty close tag.");
          this.text += "</>";
          return;
        }
        const handler = this.closeTagHandler;
        let l = tags.length;
        while (l-- > 0) {
          const tag = this.tag = tags.pop();
          this.topNS = tag.ns;
          handler === null || handler === void 0 ? void 0 : handler(tag);
          if (tag.name === name) {
            break;
          }
          this.fail("unexpected close tag.");
        }
        if (l === 0) {
          this.closedRoot = true;
        } else if (l < 0) {
          this.fail(`unmatched closing tag: ${name}.`);
          this.text += `</${name}>`;
        }
      }
      /**
       * Resolves an entity. Makes any necessary well-formedness checks.
       *
       * @param entity The entity to resolve.
       *
       * @returns The parsed entity.
       */
      parseEntity(entity) {
        if (entity[0] !== "#") {
          const defined = this.ENTITIES[entity];
          if (defined !== void 0) {
            return defined;
          }
          this.fail(this.isName(entity) ? "undefined entity." : "disallowed character in entity name.");
          return `&${entity};`;
        }
        let num = NaN;
        if (entity[1] === "x" && /^#x[0-9a-f]+$/i.test(entity)) {
          num = parseInt(entity.slice(2), 16);
        } else if (/^#[0-9]+$/.test(entity)) {
          num = parseInt(entity.slice(1), 10);
        }
        if (!this.isChar(num)) {
          this.fail("malformed character entity.");
          return `&${entity};`;
        }
        return String.fromCodePoint(num);
      }
    };
    exports.SaxesParser = SaxesParser2;
  }
});

// scripts/install-slicer-extension.mjs
import { mkdir as mkdir2, readFile as readFile3, writeFile as writeFile2, copyFile, realpath as realpath3, lstat as lstat3 } from "node:fs/promises";
import { realpathSync } from "node:fs";
import path3 from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { randomUUID as randomUUID3 } from "node:crypto";

// extensions/forge-slicer/protocol.js
var PROTOCOL = Object.freeze({
  version: 1,
  extension_id: "lkalcgppeejlaioplgipmmgdcpncofck",
  host_name: "com.elevare3d.forge_slicer",
  profile_id: "bambu-a1-04-pla-020-v1",
  chunk_bytes: 393216,
  max_file_bytes: 67108864,
  allowed_origins: ["https://elevare3d.lovable.app", "https://id-preview--f4da8107-e6b0-434d-90a9-de1c21edf12f.lovable.app", "https://elevare3d.com.br"]
});

// scripts/forge-slicer-worker.mjs
import { readFile, writeFile, mkdir, rm, realpath, open, lstat } from "node:fs/promises";
import path from "node:path";
var import_saxes = __toESM(require_saxes(), 1);
import { createHash, randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { inflateRawSync, deflateRawSync } from "node:zlib";
import { StringDecoder } from "node:string_decoder";
var PROFILE = "bambu-a1-04-pla-020-v1";
var ENGINE_VERSION = "02.08.02.61";
var MAX_FILE_BYTES = 64 * 1024 * 1024;
var MAX_EXPANDED = 512 * 1024 * 1024;
var MAX_MEMBER = 128 * 1024 * 1024;
var COMPATIBLE_NORMALIZATION = "bambu_compatible_printers_xml_escape_v1";
var EXTRUDER_NORMALIZATION = "bambu_print_extruder_variant_xml_escape_v1";
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
var fail = (message) => {
  throw new Error(message);
};
function verificationCube() {
  const vertices = [[0, 0, 0], [20, 0, 0], [20, 20, 0], [0, 20, 0], [0, 0, 20], [20, 0, 20], [20, 20, 20], [0, 20, 20]];
  const faces = [[0, 2, 1], [0, 3, 2], [4, 5, 6], [4, 6, 7], [0, 1, 5], [0, 5, 4], [1, 2, 6], [1, 6, 5], [2, 3, 7], [2, 7, 6], [3, 0, 4], [3, 4, 7]];
  return Buffer.from(["solid forge_verification_cube", ...faces.flatMap((face) => ["facet normal 0 0 0", "outer loop", ...face.map((i) => "vertex " + vertices[i].join(" ")), "endloop", "endfacet"]), "endsolid forge_verification_cube"].join("\n"));
}
var crcTable = Uint32Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let i = 0; i < 8; i++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
  return c >>> 0;
});
var crc32 = (bytes) => {
  let c = 4294967295;
  for (const b of bytes) c = crcTable[(c ^ b) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
};
function readZip(bytes) {
  if (bytes.length > MAX_FILE_BYTES || bytes.length < 22) fail("Arquivo 3MF fora do limite.");
  let end = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (bytes.readUInt32LE(i) === 101010256 && i + 22 + bytes.readUInt16LE(i + 20) === bytes.length) {
      end = i;
      break;
    }
  }
  if (end < 0 || bytes.readUInt16LE(end + 4) || bytes.readUInt16LE(end + 6)) fail("ZIP multipartes n\xE3o permitido.");
  const count = bytes.readUInt16LE(end + 10), offset = bytes.readUInt32LE(end + 16), size = bytes.readUInt32LE(end + 12);
  if (!count || count > 4096 || bytes.readUInt16LE(end + 8) !== count || offset + size !== end) fail("Estrutura ZIP inv\xE1lida ou muito grande.");
  const entries = [], names = /* @__PURE__ */ new Set(), ranges = [];
  let cursor = offset, expanded = 0;
  for (let n = 0; n < count; n++) {
    if (cursor + 46 > end || bytes.readUInt32LE(cursor) !== 33639248) fail("Diret\xF3rio ZIP inv\xE1lido.");
    const flags = bytes.readUInt16LE(cursor + 8), method = bytes.readUInt16LE(cursor + 10);
    const crc = bytes.readUInt32LE(cursor + 16), packedSize = bytes.readUInt32LE(cursor + 20), plainSize = bytes.readUInt32LE(cursor + 24);
    const nameSize = bytes.readUInt16LE(cursor + 28), extra = bytes.readUInt16LE(cursor + 30), comment = bytes.readUInt16LE(cursor + 32);
    const local = bytes.readUInt32LE(cursor + 42), external = bytes.readUInt32LE(cursor + 38);
    if (cursor + 46 + nameSize + extra + comment > end || flags & ~2056 || ![0, 8].includes(method) || plainSize > MAX_MEMBER || packedSize > MAX_FILE_BYTES || local === 4294967295 || (external >>> 16 & 61440) === 40960) fail("Membro ZIP n\xE3o suportado.");
    const nameBytes = bytes.subarray(cursor + 46, cursor + 46 + nameSize), name = nameBytes.toString("utf8");
    if (!name || !Buffer.from(name).equals(nameBytes) || /[\x00-\x1f\\:]/.test(name) || name.startsWith("/") || name.split("/").some((p) => p === ".." || p === ".") || names.has(name.toLowerCase())) fail("Caminho ZIP inv\xE1lido ou duplicado.");
    names.add(name.toLowerCase());
    expanded += plainSize;
    if (expanded > MAX_EXPANDED || local + 30 > offset || bytes.readUInt32LE(local) !== 67324752) fail("Expans\xE3o ZIP acima do limite.");
    const localName = bytes.readUInt16LE(local + 26), localExtra = bytes.readUInt16LE(local + 28), start = local + 30 + localName + localExtra;
    if (bytes.readUInt16LE(local + 6) !== flags || bytes.readUInt16LE(local + 8) !== method || start + packedSize > offset || !bytes.subarray(local + 30, local + 30 + localName).equals(nameBytes)) fail("Cabe\xE7alho ZIP inconsistente.");
    ranges.push([local, start + packedSize]);
    const compressed = bytes.subarray(start, start + packedSize);
    let data;
    try {
      data = method === 0 ? compressed : inflateRawSync(compressed, { maxOutputLength: Math.min(MAX_MEMBER, plainSize + 1) });
    } catch {
      fail("Conte\xFAdo ZIP inv\xE1lido ou acima do limite.");
    }
    if (data.length !== plainSize || crc32(data) !== crc) fail("Integridade ZIP inv\xE1lida.");
    entries.push({ name, data, compressed, method, crc });
    cursor += 46 + nameSize + extra + comment;
  }
  if (cursor !== end) fail("Diret\xF3rio ZIP inconsistente.");
  ranges.sort((a, b) => a[0] - b[0]);
  if (ranges.some((r, i) => i && r[0] < ranges[i - 1][1])) fail("Membros ZIP sobrepostos.");
  return entries;
}
function writeZip(entries) {
  const locals = [], directory = [];
  let offset = 0;
  for (const entry of entries) {
    const name = Buffer.from(entry.name), data = entry.data;
    const packed = entry.compressed ?? deflateRawSync(data), method = entry.compressed ? entry.method : 8;
    const crc = crc32(data), header = Buffer.alloc(30), central = Buffer.alloc(46);
    header.writeUInt32LE(67324752);
    header.writeUInt16LE(20, 4);
    header.writeUInt16LE(2048, 6);
    header.writeUInt16LE(method, 8);
    header.writeUInt32LE(crc, 14);
    header.writeUInt32LE(packed.length, 18);
    header.writeUInt32LE(data.length, 22);
    header.writeUInt16LE(name.length, 26);
    central.writeUInt32LE(33639248);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(2048, 8);
    central.writeUInt16LE(method, 10);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(packed.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt32LE(offset, 42);
    locals.push(header, name, packed);
    directory.push(central, name);
    offset += header.length + name.length + packed.length;
  }
  const end = Buffer.alloc(22), dir = Buffer.concat(directory);
  end.writeUInt32LE(101010256);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(dir.length, 12);
  end.writeUInt32LE(offset, 16);
  const result = Buffer.concat([...locals, dir, end]);
  if (result.length > MAX_FILE_BYTES) fail("Resultado 3MF acima de 64 MB.");
  return result;
}
function parseXml(bytes, onOpen = () => {
}, onClose = () => {
}) {
  const parser = new import_saxes.SaxesParser({ xmlns: true });
  parser.on("error", () => fail("O 3MF cont\xE9m XML inv\xE1lido."));
  parser.on("doctype", () => fail("Declara\xE7\xF5es DTD n\xE3o s\xE3o permitidas no 3MF."));
  parser.on("opentag", (tag) => {
    for (const attribute of Object.values(tag.attributes)) {
      if (attribute.local === "TargetMode" && attribute.value.toLowerCase() === "external") fail("Refer\xEAncia externa n\xE3o permitida no 3MF.");
      if (["path", "href", "src", "Target"].includes(attribute.local) && /^(?:[a-z]+:|\\\\|\/\/)|(?:^|\/)\.\.(?:\/|$)/i.test(attribute.value)) fail("Refer\xEAncia externa n\xE3o permitida no 3MF.");
    }
    const attrs = Object.fromEntries(Object.values(tag.attributes).map((a) => [a.local, a.value]));
    if (attrs.TargetMode?.toLowerCase() === "external" || tag.local === "Relationship" && /^(?:[a-z]+:|\/\/)/i.test(attrs.Target ?? "")) fail("Refer\xEAncia externa n\xE3o permitida no 3MF.");
    onOpen(tag.local, attrs);
  });
  parser.on("closetag", (tag) => onClose(tag.local));
  const decoder = new StringDecoder("utf8");
  for (let n = 0; n < bytes.length; n += 65536) parser.write(decoder.write(bytes.subarray(n, n + 65536)));
  parser.write(decoder.end()).close();
}
function unsafeSettings(node) {
  if (!node || typeof node !== "object") return false;
  return Object.entries(node).some(([key, value]) => /post[_ -]?(?:process|processing)/i.test(key) ? Array.isArray(value) ? value.some((v) => String(v).trim()) : value != null && String(value).trim() !== "" : unsafeSettings(value));
}
function validateArchive(entries, source = false) {
  if (!entries.some((e) => /^3D\/.+\.model$/i.test(e.name))) fail("O 3MF n\xE3o cont\xE9m geometria.");
  for (const entry of entries) {
    if (/\.(?:xml|model|rels)$/i.test(entry.name) || /\.config$/i.test(entry.name) && entry.data.toString("utf8", 0, 100).trimStart().startsWith("<")) parseXml(entry.data, (_tag, attrs) => {
      if (source && /post[_ -]?(?:process|processing)/i.test(attrs.key ?? "") && attrs.value?.trim()) fail("Script de p\xF3s-processamento n\xE3o permitido.");
      for (const key of ["path", "href", "src"]) if (/^(?:[a-z]+:|\\\\|\/\/)|(?:^|\/)\.\.(?:\/|$)/i.test(attrs[key] ?? "")) fail("Refer\xEAncia externa n\xE3o permitida no 3MF.");
    });
    if (source && /(?:project_settings|print_config|Slic3r).*\.(?:config|ini)$/i.test(entry.name)) {
      if (entry.data.length > 8 * 1024 * 1024) fail("Configura\xE7\xE3o 3MF acima do limite.");
      const text = entry.data.toString("utf8").trim();
      if (text.startsWith("{")) {
        let settings;
        try {
          settings = JSON.parse(text);
        } catch {
          fail("Configura\xE7\xE3o 3MF inv\xE1lida.");
        }
        if (unsafeSettings(settings)) fail("Remova os scripts de p\xF3s-processamento do arquivo antes de simular.");
      } else if (/^\s*(?:;\s*)?post[_ -]?(?:process|processing)[^=\n]*=\s*[^\s\n]+/im.test(text)) fail("Script de p\xF3s-processamento n\xE3o permitido.");
    }
  }
}
function projectGeometry(entries) {
  const documents = /* @__PURE__ */ new Map();
  const number = (value) => {
    const n = Number(value);
    if (!Number.isFinite(n)) fail("Coordenada inv\xE1lida no 3MF.");
    return String(Math.round(n * 1e6) / 1e6);
  };
  for (const entry of entries.filter((e) => e.name.endsWith(".model"))) {
    const objects = /* @__PURE__ */ new Map();
    let current = null, hash = null, unit = "millimeter";
    parseXml(entry.data, (tag, attrs) => {
      if (tag === "model") unit = attrs.unit ?? "millimeter";
      if (tag === "object") {
        current = { components: [], mesh: null };
        objects.set(attrs.id, current);
      }
      if (tag === "mesh" && current) hash = createHash("sha256").update("unit:" + unit + "\n");
      if (tag === "vertex" && hash) hash.update("v:" + [attrs.x, attrs.y, attrs.z].map(number).join(",") + "\n");
      if (tag === "triangle" && hash) hash.update("t:" + Object.keys(attrs).sort().filter((k) => attrs[k] !== "").map((k) => k + ":" + attrs[k]).join(",") + "\n");
      if (tag === "component" && current) {
        const matrix = (attrs.transform ?? "1 0 0 0 1 0 0 0 1 0 0 0").trim().split(/\s+/).map(Number);
        if (matrix.length !== 12 || matrix.some((n) => !Number.isFinite(n))) fail("Transforma\xE7\xE3o de componente inv\xE1lida no 3MF.");
        current.components.push({ file: attrs.path ? path.posix.resolve(path.posix.dirname("/" + entry.name), attrs.path).slice(1) : entry.name, id: attrs.objectid, matrix });
      }
    }, (tag) => {
      if (tag === "mesh" && current) {
        current.mesh = hash.digest("hex");
        hash = null;
      }
      if (tag === "object") current = null;
    });
    documents.set(entry.name, objects);
  }
  const cache = /* @__PURE__ */ new Map();
  function fingerprint(file, id, seen = /* @__PURE__ */ new Set()) {
    const key = file + ":" + id;
    if (cache.has(key)) return cache.get(key);
    if (seen.has(key) || seen.size > 64) fail("Componente 3MF c\xEDclico ou muito profundo.");
    const node = documents.get(file)?.get(id);
    if (!node) fail("N\xE3o foi poss\xEDvel conferir a geometria de uma pe\xE7a do 3MF.");
    const next = /* @__PURE__ */ new Set([...seen, key]);
    let result = node.mesh;
    if (node.components.length) {
      const minimum = [9, 10, 11].map((axis) => Math.min(...node.components.map((c) => c.matrix[axis])));
      const components = node.components.map((c) => JSON.stringify({
        mesh: fingerprint(c.file, c.id, next),
        linear: c.matrix.slice(0, 9).map(number),
        translation: c.matrix.slice(9).map((n, i) => number(n - minimum[i]))
      })).sort();
      result = sha256(Buffer.from(JSON.stringify({ mesh: result, components })));
    }
    if (!result) fail("Pe\xE7a sem geometria verific\xE1vel no 3MF.");
    cache.set(key, result);
    return result;
  }
  return { fingerprint, part(objectId, partId) {
    const node = documents.get("3D/3dmodel.model")?.get(objectId);
    const targets = node?.components.filter((c) => c.id === partId) ?? [];
    if (targets.length === 1) {
      const target = targets[0], minimum = [9, 10, 11].map((axis) => Math.min(...node.components.map((c) => c.matrix[axis])));
      return sha256(Buffer.from(JSON.stringify({
        mesh: fingerprint(target.file, target.id),
        linear: target.matrix.slice(0, 9).map(number),
        translation: target.matrix.slice(9).map((n, i) => number(n - minimum[i]))
      })));
    }
    if (node?.mesh && objectId === partId) return fingerprint("3D/3dmodel.model", objectId);
    fail("N\xE3o foi poss\xEDvel conferir a geometria de uma parte do projeto 3MF.");
  } };
}
function nativeProjectLayout(entries) {
  const config = entries.find((e) => e.name === "Metadata/model_settings.config");
  const settings = entries.find((e) => e.name === "Metadata/project_settings.config");
  if (!config || !settings) fail("Para simular um 3MF, salve-o como projeto completo no Bambu Studio. A importa\xE7\xE3o de um arquivo j\xE1 fatiado continua dispon\xEDvel.");
  if (settings.data.length > 8 * 1024 * 1024) fail("Configura\xE7\xE3o 3MF acima do limite.");
  let project;
  try {
    project = JSON.parse(settings.data.toString("utf8"));
  } catch {
    fail("Configura\xE7\xE3o do projeto 3MF inv\xE1lida.");
  }
  const types = project.filament_type, colors = project.filament_colour;
  if (!Array.isArray(types) || !types.length || types.length > 32 || !Array.isArray(colors) || colors.length !== types.length || types.some((type) => typeof type !== "string" || type.trim().toUpperCase() !== "PLA") || colors.some((color) => typeof color !== "string" || !/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(color))) {
    fail("O perfil A1/PLA aceita somente projetos com filamentos PLA e cores definidas em todos os slots. Use um perfil compat\xEDvel no Bambu Studio ou importe o 3MF j\xE1 fatiado.");
  }
  const objects = /* @__PURE__ */ new Map(), plates = [];
  let object = null, plate = null, instance = null, part = null;
  parseXml(config.data, (tag, attrs) => {
    if (tag === "object") {
      object = { id: attrs.id, name: "", extruder: "", parts: [] };
      objects.set(attrs.id, object);
    }
    if (tag === "part" && object) {
      part = { id: attrs.id, extruder: "", role: attrs.subtype ?? "normal_part" };
      object.parts.push(part);
    }
    if (tag === "plate") {
      plate = { index: 0, instances: [] };
      plates.push(plate);
    }
    if (tag === "model_instance" && plate) {
      instance = {};
      plate.instances.push(instance);
    }
    if (tag === "metadata") {
      if (instance && ["object_id", "instance_id"].includes(attrs.key)) instance[attrs.key] = attrs.value;
      else if (plate && attrs.key === "plater_id") plate.index = Number(attrs.value);
      else if (part && attrs.key === "extruder") part.extruder = attrs.value;
      else if (object && !part && ["name", "extruder"].includes(attrs.key)) object[attrs.key] = attrs.value;
    }
  }, (tag) => {
    if (tag === "part") part = null;
    if (tag === "object") object = null;
    if (tag === "model_instance") instance = null;
    if (tag === "plate") plate = null;
  });
  const model = entries.find((e) => e.name === "3D/3dmodel.model");
  if (!model) fail("Geometria principal do 3MF n\xE3o encontrada.");
  const builds = /* @__PURE__ */ new Map(), nextInstance = /* @__PURE__ */ new Map();
  parseXml(model.data, (tag, attrs) => {
    if (tag !== "item") return;
    const index = nextInstance.get(attrs.objectid) ?? 0;
    nextInstance.set(attrs.objectid, index + 1);
    const matrix = (attrs.transform ?? "1 0 0 0 1 0 0 0 1 0 0 0").trim().split(/\s+/).map(Number);
    if (matrix.length !== 12 || matrix.some((n) => !Number.isFinite(n))) fail("Transforma\xE7\xE3o de c\xF3pia inv\xE1lida no 3MF.");
    builds.set(attrs.objectid + ":" + index, { printable: attrs.printable !== "0" && attrs.printable !== "false", linear: matrix.slice(0, 9).map((n) => Math.round(n * 1e6) / 1e6) });
  });
  const assigned = /* @__PURE__ */ new Set(), usedObjects = /* @__PURE__ */ new Set(), usedIndices = /* @__PURE__ */ new Set();
  const result = plates.map((p) => {
    const instances = p.instances.filter((i) => builds.get(i.object_id + ":" + i.instance_id)?.printable);
    if (!instances.length) return null;
    if (!Number.isInteger(p.index) || p.index < 1 || usedIndices.has(p.index)) fail("Identifica\xE7\xE3o de placa inv\xE1lida no 3MF.");
    usedIndices.add(p.index);
    const keys = instances.map((i) => {
      const key = i.object_id + ":" + i.instance_id;
      if (!objects.has(i.object_id) || assigned.has(key) || !/^\d+$/.test(i.instance_id ?? "")) fail("V\xEDnculo de c\xF3pia inv\xE1lido no 3MF.");
      assigned.add(key);
      usedObjects.add(i.object_id);
      return key;
    }).sort();
    return { index: p.index, instances: keys };
  }).filter(Boolean).sort((a, b) => a.index - b.index);
  if (!result.length || [...builds].some(([key, item]) => item.printable && !assigned.has(key))) fail("Todas as c\xF3pias imprim\xEDveis precisam estar vinculadas \xE0s placas do projeto 3MF.");
  const selectedObjects = [...usedObjects].sort().map((id) => ({ ...objects.get(id), parts: [...objects.get(id).parts].sort((a, b) => a.id.localeCompare(b.id)) }));
  const geometry = projectGeometry(entries), physicalKeys = /* @__PURE__ */ new Map();
  for (const obj of selectedObjects) {
    for (const slot of [obj.extruder, ...obj.parts.map((p) => p.extruder)].filter(Boolean)) {
      if (!/^\d+$/.test(slot) || Number(slot) > types.length) fail("Slot de filamento inv\xE1lido na composi\xE7\xE3o 3MF.");
    }
    const parentSlot = Number(obj.extruder) || 1;
    obj.geometry_sha256 = geometry.fingerprint("3D/3dmodel.model", obj.id);
    const parts = obj.parts.map((p) => JSON.stringify({ geometry_sha256: geometry.part(obj.id, p.id), slot: Number(p.extruder) || parentSlot, role: p.role })).sort();
    obj.physical_key = sha256(Buffer.from(JSON.stringify({ name: obj.name, geometry_sha256: obj.geometry_sha256, slot: parentSlot, parts })));
    physicalKeys.set(obj.id, obj.physical_key);
  }
  for (const p of result) p.physical_instances = p.instances.map((key) => sha256(Buffer.from(JSON.stringify({ object: physicalKeys.get(key.split(":")[0]), linear: builds.get(key).linear })))).sort();
  return { plates: result, objects: selectedObjects, colors: colors.map((c) => c.toUpperCase()), materials: types.map((t) => t.trim().toUpperCase()) };
}
function verifyNativeProject(source, entries, metrics) {
  const output = nativeProjectLayout(entries);
  const physicalPlates = (layout) => layout.plates.map((p) => ({ index: p.index, physical_instances: p.physical_instances }));
  if (JSON.stringify(physicalPlates(source)) !== JSON.stringify(physicalPlates(output)) || JSON.stringify(source.colors) !== JSON.stringify(output.colors) || JSON.stringify(source.materials) !== JSON.stringify(output.materials)) {
    fail("O fatiador alterou placas, c\xF3pias ou slots do projeto 3MF. O resultado n\xE3o foi aplicado.");
  }
  if (JSON.stringify(source.plates.map((p) => p.index)) !== JSON.stringify(metrics.plates.map((p) => p.plate_index).sort((a, b) => a - b))) fail("As m\xE9tricas n\xE3o correspondem a todas as placas do projeto.");
  for (const plate of metrics.plates) for (const filament of plate.filaments) {
    const slot = filament.id - 1;
    if (!Number.isInteger(slot) || slot < 0 || slot >= source.colors.length || filament.material_code?.toUpperCase() !== source.materials[slot] || filament.color_hex?.toUpperCase().slice(0, 7) !== source.colors[slot].slice(0, 7)) fail("O fatiador alterou o material ou a cor de um slot do projeto 3MF.");
  }
  return { plates_verified: true, copies_verified: true, slots_verified: true };
}
function normalizeOutput(raw, compatiblePrinters, extruderVariant) {
  if (JSON.stringify(compatiblePrinters) !== '["Bambu Lab A1 0.4 nozzle"]' || JSON.stringify(extruderVariant) !== '["Direct Drive Standard"]') fail("O perfil oficial n\xE3o corresponde \xE0 normaliza\xE7\xE3o autorizada.");
  const entries = readZip(raw), normalizations = [];
  const allowed = [
    ["compatible_printers", "Bambu Lab A1 0.4 nozzle", COMPATIBLE_NORMALIZATION],
    ["print_extruder_variant", "Direct Drive Standard", EXTRUDER_NORMALIZATION]
  ];
  const normalized = entries.map((entry) => {
    if (entry.name !== "Metadata/model_settings.config") return entry;
    let text = entry.data.toString("utf8");
    for (const [key, value, marker] of allowed) {
      const expected = '<metadata key="' + key + '" value=""' + value + '""/>';
      if (!text.includes(expected)) continue;
      text = text.replaceAll(expected, '<metadata key="' + key + '" value="&quot;' + value + '&quot;"/>');
      normalizations.push(marker);
    }
    return normalizations.length ? { name: entry.name, data: Buffer.from(text) } : entry;
  });
  if (normalizations.length) normalized.push({ name: "Metadata/forge_slicer_normalization.json", data: Buffer.from(JSON.stringify({ raw_output_sha256: sha256(raw), normalizations, engine_version: ENGINE_VERSION })) });
  validateArchive(normalized);
  const output = normalizations.length ? writeZip(normalized) : raw;
  const verified = readZip(output);
  validateArchive(verified);
  for (const original of entries.filter((e) => /\.(?:model|gcode)$/i.test(e.name))) {
    if (!verified.some((e) => e.name === original.name && sha256(e.data) === sha256(original.data))) fail("A geometria ou o G-code foi alterado durante a normaliza\xE7\xE3o.");
  }
  return { output, entries: verified, normalizations };
}
function readMetrics(entries, report) {
  if (report.return_code !== 0 || !Array.isArray(report.sliced_plates) || !report.sliced_plates.length) fail("O Bambu Studio n\xE3o confirmou o fatiamento.");
  const info = entries.find((e) => e.name === "Metadata/slice_info.config");
  if (!info) fail("O fatiador n\xE3o retornou tempos e consumo.");
  const plates = [];
  let plate = null, version = null;
  parseXml(info.data, (tag, a) => {
    if (tag === "header" && a.key === "X-BBL-Client-Version") version = a.value;
    if (tag === "plate") {
      plate = { metadata: {}, filaments: [] };
      plates.push(plate);
    }
    if (tag === "metadata" && plate) plate.metadata[a.key] = a.value;
    if (tag === "filament" && plate) plate.filaments.push(a);
  }, (tag) => {
    if (tag === "plate") plate = null;
  });
  if (!version) parseXml(info.data, (tag, a) => {
    if (a.key === "X-BBL-Client-Version") version = a.value;
  });
  if (version !== ENGINE_VERSION || plates.length !== report.sliced_plates.length) fail("Vers\xE3o ou quantidade de placas inesperada.");
  const positive = (v, max) => {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0 || n > max) fail("M\xE9trica ausente ou inv\xE1lida no fatiamento.");
    return n;
  };
  const result = plates.map((p, index) => {
    const time = positive(p.metadata.prediction, 31536e3), weight = positive(p.metadata.weight, 1e6);
    const jsonPlate = report.sliced_plates.find((j) => j.id === Number(p.metadata.index)) ?? report.sliced_plates[index];
    const jsonWeight = jsonPlate.filaments?.reduce((sum, f) => sum + Number(f.total_used_g), 0);
    if (!Number.isFinite(jsonWeight) || Math.abs(jsonWeight - weight) > Math.max(0.1, weight * 0.01) || Math.abs(positive(jsonPlate.total_predication, 31536e3) - time) > 2) fail("As m\xE9tricas do JSON e do 3MF n\xE3o conferem.");
    return {
      plate_index: Number(p.metadata.index),
      time_seconds: time,
      weight_grams: weight,
      printer_model_id: p.metadata.printer_model_id || "Bambu Lab A1",
      nozzle_diameters: p.metadata.nozzle_diameters || "0.4",
      filaments: p.filaments.map((f) => ({
        id: Number(f.id),
        material_code: f.type,
        color_hex: f.color,
        weight_grams: positive(f.used_g, 1e6),
        length_meters: positive(f.used_m, 1e6)
      }))
    };
  });
  return { time_seconds: result.reduce((s, p) => s + p.time_seconds, 0), weight_grams: result.reduce((s, p) => s + p.weight_grams, 0), plates: result };
}
async function resolveOfficialProfiles(enginePath, target) {
  const vendor = path.join(path.dirname(enginePath), "resources", "profiles", "BBL");
  async function load(kind, name, seen = []) {
    if (seen.includes(name) || /[\\/]/.test(name)) fail("Heran\xE7a de perfil inv\xE1lida.");
    const node = JSON.parse((await readFile(path.join(vendor, kind, name + ".json"), "utf8")).replace(/^\uFEFF/, ""));
    const parents = node.inherits ? await load(kind, node.inherits, [...seen, name]) : {};
    for (const include of node.include ?? []) Object.assign(parents, await load(kind, include, [...seen, name]));
    Object.assign(parents, node);
    delete parents.inherits;
    delete parents.include;
    return parents;
  }
  await mkdir(target, { recursive: true });
  const sources = { machine: ["machine", "Bambu Lab A1 0.4 nozzle"], process: ["process", "0.20mm Standard @BBL A1"], filament: ["filament", "Generic PLA @BBL A1"] };
  const profiles = {};
  for (const [kind, [folder, name]] of Object.entries(sources)) {
    const data = Buffer.from(JSON.stringify(await load(folder, name), null, 2));
    await writeFile(path.join(target, kind + ".json"), data, { mode: 384 });
    profiles[kind] = sha256(data);
  }
  return profiles;
}
async function safeRemoveJob(root, job) {
  if (!UUID.test(path.basename(job))) fail("Diret\xF3rio de trabalho inv\xE1lido.");
  const resolvedRoot = await realpath(root), resolved = await realpath(job).catch(() => null);
  if (!resolved) return;
  if (path.dirname(path.resolve(job)).toLowerCase() !== path.resolve(root).toLowerCase() || path.dirname(resolved).toLowerCase() !== resolvedRoot.toLowerCase() || (await lstat(job)).isSymbolicLink()) fail("Diret\xF3rio de trabalho fora da \xE1rea privada.");
  await rm(resolved, { recursive: true, force: true });
}
async function runSimulation({ enginePath, profileDir, profileHashes, source, extension, workspace, timeoutMs = 6e5, signal, onChild = () => {
}, spawnProcess = spawn }) {
  if (!["stl", "3mf"].includes(extension) || !source.length || source.length > MAX_FILE_BYTES) fail("Arquivo de simula\xE7\xE3o inv\xE1lido.");
  let nativeLayout = null;
  if (extension === "3mf") {
    const entries2 = readZip(source);
    validateArchive(entries2, true);
    nativeLayout = nativeProjectLayout(entries2);
  }
  await mkdir(workspace, { recursive: false });
  const outputDir = path.join(workspace, "output"), dataDir = path.join(workspace, "isolated-data");
  await mkdir(outputDir);
  await mkdir(dataDir);
  const profiles = {};
  for (const kind of ["machine", "process", "filament"]) {
    const bytes = await readFile(path.join(profileDir, kind + ".json"));
    if (sha256(bytes) !== profileHashes[kind]) fail("O perfil do fatiador foi alterado. Execute a configura\xE7\xE3o novamente.");
    profiles[kind] = JSON.parse(bytes);
    await writeFile(path.join(workspace, kind + ".json"), bytes, { mode: 384 });
  }
  const input = path.join(workspace, "source." + extension);
  await writeFile(input, source, { mode: 384 });
  const args = [
    "--datadir",
    dataDir,
    "--debug",
    "3",
    "--load-settings",
    path.join(workspace, "machine.json") + ";" + path.join(workspace, "process.json"),
    ...nativeLayout ? [] : ["--load-filaments", path.join(workspace, "filament.json")],
    "--curr-bed-type",
    "Textured PEI Plate",
    "--orient",
    nativeLayout ? "0" : "1",
    "--arrange",
    nativeLayout ? "0" : "1",
    "--slice",
    "0",
    "--export-slicedata",
    path.join(outputDir, "slice-data"),
    "--export-3mf",
    "simulation.3mf",
    "--outputdir",
    outputDir,
    input
  ];
  const env = { ...process.env, APPDATA: dataDir, LOCALAPPDATA: dataDir, USERPROFILE: dataDir, HOME: dataDir };
  const started = Date.now();
  await new Promise((resolve, reject) => {
    const child = spawnProcess(enginePath, args, { cwd: workspace, env, windowsHide: true, shell: false, stdio: "ignore", signal });
    onChild(child);
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error("A simula\xE7\xE3o ultrapassou dez minutos. Simplifique o arquivo e tente novamente."));
    }, Math.min(timeoutMs, 6e5));
    child.once("error", (error) => {
      clearTimeout(timer);
      reject(new Error(error.name === "AbortError" ? "Simula\xE7\xE3o interrompida." : "N\xE3o foi poss\xEDvel iniciar o Bambu Studio."));
    });
    child.once("exit", (code) => {
      clearTimeout(timer);
      code === 0 ? resolve() : reject(new Error("O Bambu Studio n\xE3o conseguiu fatiar este arquivo (c\xF3digo " + code + ")."));
    });
  });
  const raw = await readFile(path.join(outputDir, "simulation.3mf"));
  const report = JSON.parse(await readFile(path.join(outputDir, "result.json"), "utf8"));
  const { output, entries, normalizations } = normalizeOutput(raw, profiles.process.compatible_printers, profiles.process.print_extruder_variant);
  const metrics = readMetrics(entries, report);
  const preservation = nativeLayout ? verifyNativeProject(nativeLayout, entries, metrics) : null;
  await writeFile(path.join(outputDir, "simulation-valid.3mf"), output, { mode: 384 });
  const stats = {
    engine: "Bambu Studio",
    engine_version: ENGINE_VERSION,
    profile_id: PROFILE,
    ...metrics,
    input_sha256: sha256(source),
    raw_output_size: raw.length,
    raw_output_sha256: sha256(raw),
    output_sha256: sha256(output),
    normalizations,
    profile_hashes: profileHashes,
    filament_source: nativeLayout ? "3mf_embedded_pla" : "official_generic_pla",
    ...preservation ? { preservation } : {},
    elapsed_seconds: Math.round((Date.now() - started) / 10) / 100,
    estimates_only: true
  };
  await writeFile(path.join(outputDir, "forge-result.json"), JSON.stringify(stats, null, 2), { mode: 384 });
  return { raw, output, stats };
}
if (false) main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});

// scripts/forge-slicer-native-host.mjs
import { readFile as readFile2, open as open2, rm as rm2, realpath as realpath2, lstat as lstat2 } from "node:fs/promises";
import path2 from "node:path";
import os from "node:os";
import { randomUUID as randomUUID2 } from "node:crypto";
var FRAME_BYTES = 1024 * 1024;
var fail2 = (message) => {
  throw new Error(message);
};
function lowerPriority(pid = process.pid) {
  try {
    os.setPriority(pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
  } catch {
    fail2("N\xE3o foi poss\xEDvel executar o fatiador em prioridade reduzida.");
  }
}
async function acquireNativeLock(root) {
  const guardPath = path2.join(root, "native-lock.guard"), lockPath = path2.join(root, "native-job.lock");
  let guard, lock;
  try {
    guard = await open2(guardPath, "wx", 384);
  } catch (error) {
    if (error.code === "EEXIST") fail2("Outra opera\xE7\xE3o do fatiador est\xE1 iniciando. Aguarde e tente novamente.");
    throw error;
  }
  try {
    await guard.writeFile(JSON.stringify({ pid: process.pid }));
    try {
      lock = await open2(lockPath, "wx", 384);
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      const info = await lstat2(lockPath);
      if (!info.isFile() || info.isSymbolicLink() || info.size > 4096) fail2("A trava local precisa ser conferida. Reinstale o conector.");
      let previous;
      try {
        previous = JSON.parse(await readFile2(lockPath, "utf8"));
      } catch {
        fail2("A trava local precisa ser conferida. Reinstale o conector.");
      }
      if (!Number.isSafeInteger(previous.pid) || previous.pid <= 0) fail2("A trava local precisa ser conferida. Reinstale o conector.");
      try {
        process.kill(previous.pid, 0);
        fail2("O fatiador est\xE1 em uso em outra janela. Aguarde a simula\xE7\xE3o atual.");
      } catch (error2) {
        if (error2.code !== "ESRCH") throw error2;
      }
      await rm2(lockPath);
      lock = await open2(lockPath, "wx", 384);
    }
    const token = randomUUID2();
    await lock.writeFile(JSON.stringify({ pid: process.pid, token, started_at: (/* @__PURE__ */ new Date()).toISOString() }));
    let released = false;
    return async () => {
      if (released) return;
      released = true;
      await lock.close();
      const current = JSON.parse(await readFile2(lockPath, "utf8").catch(() => "{}"));
      if (current.token === token) await rm2(lockPath, { force: true });
    };
  } finally {
    await guard.close();
    await rm2(guardPath, { force: true });
  }
}
if (false) main().catch((error) => {
  process.stderr.write(publicError(error) + "\n");
  process.exitCode = 1;
});

// scripts/install-slicer-extension.mjs
var fail3 = (message) => {
  throw new Error(message);
};
var quote = (value) => "'" + value.replaceAll("'", "''") + "'";
var command = (executable, args) => {
  const env = /powershell[.]exe$/i.test(executable) ? { ...process.env, PSModulePath: path3.join(process.env.SystemRoot || "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "Modules") } : process.env;
  const result = spawnSync(executable, args, { encoding: "utf8", windowsHide: true, shell: false, timeout: 3e4, env });
  if (result.error || result.status !== 0) fail3("N\xE3o foi poss\xEDvel configurar o conector local no Windows.");
  return result.stdout.trim();
};
function nativeInstallReview({ baseDirectory = process.env.LOCALAPPDATA, enginePath = "C:\\Program Files\\Bambu Studio\\bambu-studio.exe" } = {}) {
  return {
    mode: "review_only",
    install_directory: path3.join(baseDirectory || "", "Elevare3D", "ForgeSlicerNative"),
    node_path: process.execPath,
    engine_path: enginePath,
    extension_id: PROTOCOL.extension_id,
    host_name: PROTOCOL.host_name,
    registry_keys: ["Google\\Chrome", "Microsoft\\Edge"].map((browser) => `HKCU\\Software\\${browser}\\NativeMessagingHosts\\${PROTOCOL.host_name}`),
    verifies_engine_offline: true,
    private_files: true,
    startup_task: false,
    background_service: false,
    network_listener: false
  };
}
function nativeManifest(launcher) {
  return { name: PROTOCOL.host_name, description: "Forge \u2022 Fatiador local sob demanda", path: launcher, type: "stdio", allowed_origins: [`chrome-extension://${PROTOCOL.extension_id}/`] };
}
function nativeLauncher(node, host, config) {
  const safe = (value) => {
    if (/["\r\n]/.test(value)) fail3("Caminho de instala\xE7\xE3o inv\xE1lido.");
    return value.replaceAll("%", "%%");
  };
  return `@echo off\r
setlocal DisableDelayedExpansion\r
"${safe(node)}" "${safe(host)}" --config "${safe(config)}" "%~1"\r
exit /b %errorlevel%\r
`;
}
async function protectNativePaths(paths) {
  const powershell = path3.join(process.env.SystemRoot || "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
  const script = `$ErrorActionPreference='Stop';$sid=[System.Security.Principal.WindowsIdentity]::GetCurrent().User;$paths=@(${paths.map(quote).join(",")});foreach($p in $paths){$isDir=[System.IO.Directory]::Exists($p);if($isDir){$acl=New-Object System.Security.AccessControl.DirectorySecurity}else{$acl=New-Object System.Security.AccessControl.FileSecurity};$acl.SetAccessRuleProtection($true,$false);foreach($identity in @($sid,(New-Object System.Security.Principal.SecurityIdentifier('S-1-5-18')),(New-Object System.Security.Principal.SecurityIdentifier('S-1-5-32-544')))){if($isDir){$rule=New-Object System.Security.AccessControl.FileSystemAccessRule($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')}else{$rule=New-Object System.Security.AccessControl.FileSystemAccessRule($identity,'FullControl','Allow')};$acl.AddAccessRule($rule)};Set-Acl -LiteralPath $p -AclObject $acl}`;
  command(powershell, ["-NoProfile", "-NonInteractive", "-EncodedCommand", Buffer.from(script, "utf16le").toString("base64")]);
}
function registerNativeManifest(manifest) {
  const reg = path3.join(process.env.SystemRoot || "C:\\Windows", "System32", "reg.exe");
  for (const browser of ["Google\\Chrome", "Microsoft\\Edge"]) command(reg, ["ADD", `HKCU\\Software\\${browser}\\NativeMessagingHosts\\${PROTOCOL.host_name}`, "/ve", "/t", "REG_SZ", "/d", manifest, "/f"]);
}
async function noLink(filename, directory = false) {
  try {
    const info = await lstat3(filename);
    if (info.isSymbolicLink() || (directory ? !info.isDirectory() : !info.isFile())) fail3("A pasta de instala\xE7\xE3o cont\xE9m um link ou arquivo inesperado.");
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}
async function installSlicerExtension({
  baseDirectory = process.env.LOCALAPPDATA,
  enginePath = "C:\\Program Files\\Bambu Studio\\bambu-studio.exe",
  packageDirectory = path3.dirname(fileURLToPath(import.meta.url)),
  register = true
} = {}, { protect = protectNativePaths, verify = runSimulation, resolveProfiles = resolveOfficialProfiles, registerManifest = registerNativeManifest, priority = lowerPriority, platform = process.platform } = {}) {
  if (platform !== "win32") fail3("Este conector requer Windows, Node.js 22+ e Bambu Studio oficial 2.8.2.61.");
  if (!baseDirectory || !path3.isAbsolute(baseDirectory)) fail3("N\xE3o foi poss\xEDvel localizar a pasta local do usu\xE1rio.");
  await mkdir2(baseDirectory, { recursive: true });
  const base = realpathSync.native(baseDirectory), logical = path3.join(baseDirectory, "Elevare3D", "ForgeSlicerNative");
  await noLink(logical, true);
  await mkdir2(logical, { recursive: true });
  const install = realpathSync.native(logical), relative = path3.relative(base, install).replaceAll("\\", "/");
  if (!/^(?:Packages\/[^/]+\/LocalCache\/Local\/)?Elevare3D\/ForgeSlicerNative$/.test(relative)) fail3("Pasta de instala\xE7\xE3o fora do destino local previsto.");
  await protect([install]);
  const release = await acquireNativeLock(install);
  try {
    const profileDir = path3.join(install, "profiles"), jobsDir = path3.join(install, "jobs");
    for (const folder of [profileDir, jobsDir]) {
      await noLink(folder, true);
      await mkdir2(folder, { recursive: true });
      if (realpathSync.native(folder) !== folder) fail3("Pasta privada fora do destino previsto.");
    }
    await protect([profileDir, jobsDir]);
    const node = realpathSync.native(process.execPath), engine = realpathSync.native(enginePath);
    const engineInfo = await lstat3(engine);
    if (!engineInfo.isFile() || engineInfo.isSymbolicLink()) fail3("Selecione a instala\xE7\xE3o oficial do Bambu Studio.");
    const engineHash = sha256(await readFile3(engine));
    for (const kind of ["machine", "process", "filament"]) await noLink(path3.join(profileDir, kind + ".json"));
    const hashes = await resolveProfiles(engine, profileDir), workspace = path3.join(jobsDir, randomUUID3());
    let verification;
    try {
      verification = await verify({
        enginePath: engine,
        profileDir,
        profileHashes: hashes,
        source: verificationCube(),
        extension: "stl",
        workspace,
        onChild: (child) => {
          if (child.pid) priority(child.pid);
        }
      });
    } finally {
      await safeRemoveJob(jobsDir, workspace);
    }
    if (verification.stats?.engine_version !== ENGINE_VERSION || verification.stats?.profile_id !== PROFILE) fail3("Use o Bambu Studio oficial 2.8.2.61 com o perfil A1/PLA 0,20mm.");
    if (sha256(await readFile3(engine)) !== engineHash) fail3("O Bambu Studio mudou durante a verifica\xE7\xE3o. Execute a instala\xE7\xE3o novamente.");
    const host = path3.join(install, "forge-slicer-native-host.mjs"), config = path3.join(install, "native.private.json"), launcher = path3.join(install, "forge-slicer-native.bat"), manifest = path3.join(install, PROTOCOL.host_name + ".json");
    for (const file of [host, config, launcher, manifest, ...["machine", "process", "filament"].map((k) => path3.join(profileDir, k + ".json"))]) await noLink(file);
    await copyFile(path3.join(packageDirectory, "native", "forge-slicer-native-host.mjs"), host);
    await writeFile2(config, JSON.stringify({
      version: 1,
      extension_id: PROTOCOL.extension_id,
      host_name: PROTOCOL.host_name,
      profile_id: PROFILE,
      engine_version: ENGINE_VERSION,
      engine_path: engine,
      engine_sha256: engineHash,
      profile_dir: profileDir,
      profile_hashes: hashes,
      jobs_dir: jobsDir
    }, null, 2), { mode: 384 });
    await writeFile2(launcher, nativeLauncher(node, host, config), { mode: 384 });
    await writeFile2(manifest, JSON.stringify(nativeManifest(launcher), null, 2), { mode: 384 });
    await protect([host, config, launcher, manifest, ...["machine", "process", "filament"].map((k) => path3.join(profileDir, k + ".json"))]);
    if (register) registerManifest(manifest);
    return { install_directory: install, manifest, extension_id: PROTOCOL.extension_id, profile_id: PROFILE, engine_version: ENGINE_VERSION };
  } finally {
    await release();
  }
}
async function main() {
  if (Number(process.versions.node.split(".")[0]) < 22) fail3("Instale o Node.js 22 ou mais recente.");
  const args = process.argv.slice(2);
  if (args.length === 1 && args[0] === "--review") {
    console.log(JSON.stringify(nativeInstallReview(), null, 2));
    return;
  }
  if (args.length && !(args.length === 2 && args[0] === "--engine")) fail3("Use node install-slicer-extension.mjs [--review | --engine caminho-do-Bambu-Studio].");
  const result = await installSlicerExtension({ ...args.length ? { enginePath: args[1] } : {} });
  console.log("Conector local instalado para Chrome e Edge. Carregue em chrome://extensions a pasta extra\xEDda que cont\xE9m manifest.json e abra o Forge. O fatiador inicia e encerra a cada solicita\xE7\xE3o.");
  console.log("Pasta privada: " + result.install_directory);
}
if (typeof FORGE_INSTALLER_LIBRARY === "undefined" && process.argv[1] && path3.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main().catch((error) => {
  console.error(error.code ? "N\xE3o foi poss\xEDvel acessar os arquivos locais. Confira o Bambu Studio e o pacote completo." : error.message);
  process.exitCode = 1;
});
export {
  installSlicerExtension,
  nativeInstallReview,
  nativeLauncher,
  nativeManifest,
  protectNativePaths,
  registerNativeManifest
};
/*! Bundled license information:

xmlchars/xml/1.0/ed5.js:
  (**
   * Character classes and associated utilities for the 5th edition of XML 1.0.
   *
   * @author Louis-Dominique Dubeau
   * @license MIT
   * @copyright Louis-Dominique Dubeau
   *)

xmlchars/xml/1.1/ed2.js:
  (**
   * Character classes and associated utilities for the 2nd edition of XML 1.1.
   *
   * @author Louis-Dominique Dubeau
   * @license MIT
   * @copyright Louis-Dominique Dubeau
   *)

xmlchars/xmlns/1.0/ed3.js:
  (**
   * Character class utilities for XML NS 1.0 edition 3.
   *
   * @author Louis-Dominique Dubeau
   * @license MIT
   * @copyright Louis-Dominique Dubeau
   *)
*/
