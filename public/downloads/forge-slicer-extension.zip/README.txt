FORGE • FATIADOR LOCAL SOB DEMANDA

Requisitos: Windows, Node.js 22+ e Bambu Studio oficial 2.8.2.61.
Perfil inicial: Bambu A1, bico 0,4mm, PLA, camada 0,20mm.

Revisão sem instalar: node install-slicer-extension.mjs --review
Esse comando apenas mostra caminhos e chaves previstas, sem alterar arquivos ou registro.

1. Extraia todo este pacote para uma pasta permanente.
2. Execute: node install-slicer-extension.mjs
   O instalador confere o motor com um cubo sintético offline, protege os arquivos locais e registra o conector apenas para o usuário atual no Chrome e Edge.
3. Abra chrome://extensions (ou edge://extensions), ative o modo do desenvolvedor, escolha Carregar sem compactação e selecione a pasta principal extraída deste pacote: a mesma que contém manifest.json e install-slicer-extension.mjs.
4. Abra o Forge e use Fatiar no computador.

O Node e o Bambu Studio abrem somente durante a solicitação. Há uma simulação por vez, em prioridade reduzida e com limite de dez minutos. Não há tarefa de inicialização, processo permanente, porta de rede ou acesso à conta Bambu/Supabase. O motor oficial não oferece a opção de limitar a dois threads.

STL usa o perfil PLA oficial. Projetos 3MF completos preservam placas, cópias, slots e cores PLA do arquivo; o resultado é recusado se houver alteração inesperada. Para outras máquinas ou materiais, importe um 3MF já fatiado no Bambu Studio. Arquivos temporários e resultados locais são removidos ao terminar, cancelar ou desconectar a extensão.

A instalação fica em %LOCALAPPDATA%\Elevare3D\ForgeSlicerNative. Atualizar o Bambu Studio exige executar o instalador novamente para conferir os novos hashes. A identidade da extensão é lkalcgppeejlaioplgipmmgdcpncofck.

Desinstalação (somente este conector):
- Cancele qualquer simulação e remova a extensão em chrome://extensions ou edge://extensions.
- Execute: reg delete "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.elevare3d.forge_slicer" /f
- Execute: reg delete "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.elevare3d.forge_slicer" /f
- Pelo Explorador, exclua somente a pasta privada ForgeSlicerNative mostrada pelo instalador. A pasta extraída deste pacote também pode ser removida após remover a extensão. Não remova outras pastas Elevare3D.

Referências oficiais do protocolo/launcher:
https://developer.chrome.com/docs/extensions/develop/concepts/native-messaging
https://github.com/GoogleChrome/chrome-extensions-samples/tree/main/api-samples/nativeMessaging/host
https://learn.microsoft.com/en-us/microsoft-edge/extensions/developer-guide/native-messaging
